<?php
    $prefix = ($mode ?? 'add') === 'edit' ? 'edit' : 'add';
    $forcedMeterType = in_array(($forceMeterType ?? ''), ['main', 'sub'], true) ? (string) $forceMeterType : null;
    $isMeterTypeForced = $forcedMeterType !== null;
    $allowSubMeter = (bool) ($hasApprovedMainForSub ?? false);
    $disableSubOption = ! $isMeterTypeForced && $prefix === 'add' && ! $allowSubMeter;
    $defaultMeterType = $prefix === 'add' ? 'main' : 'sub';
    $selectedMeterType = $forcedMeterType ?? ($disableSubOption ? 'main' : old('meter_type', $defaultMeterType));
?>

<div class="meter-form-field">
    <label class="meter-form-label" for="<?php echo e($prefix); ?>_meter_name">Meter Name <span class="meter-required">*</span></label>
    <input class="meter-form-control" id="<?php echo e($prefix); ?>_meter_name" type="text" name="meter_name" required maxlength="255" value="<?php echo e(old('meter_name')); ?>" placeholder="e.g. Main Meter, 2nd Floor Panel">
</div>

<div class="meter-form-field">
    <label class="meter-form-label" for="<?php echo e($prefix); ?>_meter_number">Meter Number</label>
    <input class="meter-form-control" id="<?php echo e($prefix); ?>_meter_number" type="text" name="meter_number" maxlength="255" value="<?php echo e(old('meter_number')); ?>" placeholder="Utility / meter serial no.">
</div>

<div class="meter-form-field">
    <label class="meter-form-label" for="<?php echo e($prefix); ?>_meter_type">Meter Type <span class="meter-required">*</span></label>
    <?php if($isMeterTypeForced): ?>
        <input type="hidden" id="<?php echo e($prefix); ?>_meter_type" name="meter_type" value="<?php echo e($selectedMeterType); ?>">
        <input class="meter-form-control" type="text" value="<?php echo e($selectedMeterType === 'main' ? 'Main Meter' : 'Sub-meter'); ?>" readonly>
    <?php else: ?>
        <select class="meter-form-control" id="<?php echo e($prefix); ?>_meter_type" name="meter_type" required>
            <option value="main" <?php if($selectedMeterType === 'main'): echo 'selected'; endif; ?>>Main Meter</option>
            <option value="sub" <?php if($selectedMeterType === 'sub'): echo 'selected'; endif; ?> <?php if($disableSubOption): echo 'disabled'; endif; ?>>
                Sub-meter<?php echo e($disableSubOption ? ' (Need approved main first)' : ''); ?>

            </option>
        </select>
    <?php endif; ?>
    <?php if(! $isMeterTypeForced && $disableSubOption): ?>
        <div class="meter-form-hint meter-form-hint-warning">Add and approve at least one Main Meter first to enable Sub-meter.</div>
    <?php endif; ?>
</div>

<div class="meter-form-field" id="<?php echo e($prefix); ?>_parent_meter_field" style="<?php echo e($selectedMeterType === 'sub' ? '' : 'display:none;'); ?>">
    <label class="meter-form-label" for="<?php echo e($prefix); ?>_parent_meter_id">Linked Main Meter</label>
    <select class="meter-form-control" id="<?php echo e($prefix); ?>_parent_meter_id" name="parent_meter_id" <?php echo e($selectedMeterType === 'sub' ? 'required' : ''); ?>>
        <option value=""><?php echo e($selectedMeterType === 'sub' ? 'Select Main Meter' : 'None'); ?></option>
        <?php $__currentLoopData = ($parentMeterOptions ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($parentMeter->id); ?>">
                <?php echo e($parentMeter->meter_name); ?> (<?php echo e(strtoupper((string) $parentMeter->meter_type)); ?>)
            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <div class="meter-form-hint">Required for Sub-meter. Choose the approved Main Meter where this sub-meter belongs.</div>
</div>

<div class="meter-form-field">
    <label class="meter-form-label" for="<?php echo e($prefix); ?>_location">Location</label>
    <input class="meter-form-control" id="<?php echo e($prefix); ?>_location" type="text" name="location" maxlength="255" value="<?php echo e(old('location')); ?>" placeholder="e.g. 2nd Floor Electrical Room">
</div>

<div class="meter-form-field">
    <label class="meter-form-label" for="<?php echo e($prefix); ?>_status">Status <span class="meter-required">*</span></label>
    <select class="meter-form-control" id="<?php echo e($prefix); ?>_status" name="status" required>
        <option value="active" <?php if(old('status', 'active') === 'active'): echo 'selected'; endif; ?>>Active</option>
        <option value="inactive" <?php if(old('status') === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
    </select>
</div>

<div class="meter-form-field">
    <label class="meter-form-label" for="<?php echo e($prefix); ?>_multiplier">Multiplier <span class="meter-required">*</span></label>
    <input class="meter-form-control" id="<?php echo e($prefix); ?>_multiplier" type="number" step="0.0001" min="0.0001" max="999999" name="multiplier" value="<?php echo e(old('multiplier', '1')); ?>" required placeholder="1.0000">
    <div class="meter-form-hint">Use 1.0 unless your meter uses CT/PT multiplier.</div>
</div>

<div class="meter-form-field full">
    <label class="meter-form-label" for="<?php echo e($prefix); ?>_baseline_kwh">Meter Baseline kWh</label>
    <input class="meter-form-control" id="<?php echo e($prefix); ?>_baseline_kwh" type="number" step="0.01" min="0" name="baseline_kwh" value="<?php echo e(old('baseline_kwh')); ?>" placeholder="Optional baseline kWh (e.g. 4200.00)">
    <div class="meter-form-hint">Used for baseline comparison and variance monitoring. Leave blank if not set yet.</div>
</div>

<div class="meter-form-field full">
    <label class="meter-form-label" for="<?php echo e($prefix); ?>_notes">Notes</label>
    <textarea class="meter-form-control meter-form-textarea" id="<?php echo e($prefix); ?>_notes" name="notes" rows="3" maxlength="2000" placeholder="Optional notes (assigned area, purpose, feeder remarks, etc.)"><?php echo e(old('notes')); ?></textarea>
</div>
<?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\modules\facilities\meters\partials\form-fields.blade.php ENDPATH**/ ?>