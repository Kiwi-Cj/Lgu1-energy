<?php $__env->startSection('title', 'Meter Archive'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $filters = $filters ?? ['q' => '', 'meter_type' => ''];
    $subOnlyMode = (bool) ($subOnlyMode ?? false);
    $mainMeterId = (int) ($mainMeterId ?? 0);
?>
<div style="padding:12px;">
    <?php if(session('success')): ?>
        <div style="margin-bottom:12px;background:#dcfce7;color:#166534;padding:12px 16px;border-radius:10px;font-weight:700;"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div style="margin-bottom:12px;background:#fee2e2;color:#b91c1c;padding:12px 16px;border-radius:10px;font-weight:700;"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap;margin-bottom:14px;">
        <div>
            <h2 style="margin:0;color:#2563eb;font-weight:800;"><?php echo e($subOnlyMode ? 'Sub-meter Archive' : 'Meter Archive'); ?></h2>
            <div style="color:#64748b;margin-top:4px;">Facility: <strong style="color:#1e293b;"><?php echo e($facility->name); ?></strong></div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <a href="<?php echo e($subOnlyMode && $mainMeterId > 0 ? route('modules.facilities.meters.main-submeters', [$facility->id, $mainMeterId]) : route('modules.facilities.energy-profile.index', $facility->id)); ?>" style="text-decoration:none;background:#f1f5f9;color:#1e293b;padding:10px 14px;border-radius:10px;font-weight:700;">
                <i class="fa fa-arrow-left"></i> Back to Energy Profile
            </a>
        </div>
    </div>

    <div style="background:#fff;border-radius:16px;box-shadow:0 2px 12px rgba(15,23,42,0.06);overflow:hidden;">
        <form method="GET" action="<?php echo e(route('modules.facilities.meters.archive', $facility->id)); ?>" style="padding:14px 16px;border-bottom:1px solid #e5e7eb;display:flex;gap:10px;flex-wrap:wrap;align-items:end;background:#fcfdff;">
            <?php if($subOnlyMode): ?>
                <input type="hidden" name="sub_only" value="1">
                <input type="hidden" name="main_meter_id" value="<?php echo e($mainMeterId); ?>">
                <input type="hidden" name="meter_type" value="sub">
            <?php endif; ?>
            <div style="display:flex;flex-direction:column;gap:5px;min-width:240px;flex:1;">
                <label style="font-size:.84rem;font-weight:700;color:#475569;">Search</label>
                <input type="text" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" placeholder="Meter name/number/location/reason" style="padding:9px 12px;border:1px solid #cbd5e1;border-radius:10px;">
            </div>
            <div style="display:flex;gap:8px;">
                <button type="submit" style="background:#2563eb;color:#fff;border:none;border-radius:10px;padding:10px 14px;font-weight:700;">Filter</button>
                <a href="<?php echo e($subOnlyMode ? route('modules.facilities.meters.archive', ['facility' => $facility->id, 'meter_type' => 'sub', 'sub_only' => '1', 'main_meter_id' => $mainMeterId]) : route('modules.facilities.meters.archive', $facility->id)); ?>" style="text-decoration:none;background:#f1f5f9;color:#334155;border-radius:10px;padding:10px 14px;font-weight:700;">Reset</a>
            </div>
        </form>

        <?php if($archivedMeters->count() === 0): ?>
            <div style="padding:22px 16px;color:#64748b;">No archived meters yet.</div>
        <?php else: ?>
            <div style="overflow-x:auto;">
                <table style="width:100%;min-width:1140px;border-collapse:collapse;">
                    <thead>
                        <tr style="background:#f8fafc;color:#334155;">
                            <th style="text-align:left;padding:12px 14px;border-bottom:1px solid #e5e7eb;">Meter</th>
                            <th style="text-align:left;padding:12px 14px;border-bottom:1px solid #e5e7eb;">Number</th>
                            <th style="text-align:right;padding:12px 14px;border-bottom:1px solid #e5e7eb;">Baseline kWh</th>
                            <th style="text-align:left;padding:12px 14px;border-bottom:1px solid #e5e7eb;">Reason</th>
                            <th style="text-align:left;padding:12px 14px;border-bottom:1px solid #e5e7eb;">Deleted By</th>
                            <th style="text-align:left;padding:12px 14px;border-bottom:1px solid #e5e7eb;">Archived At</th>
                            <th style="text-align:center;padding:12px 14px;border-bottom:1px solid #e5e7eb;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $archivedMeters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="padding:12px 14px;border-bottom:1px solid #f1f5f9;color:#1e293b;font-weight:700;"><?php echo e($meter->meter_name); ?></td>
                                <td style="padding:12px 14px;border-bottom:1px solid #f1f5f9;color:#475569;"><?php echo e($meter->meter_number ?: '-'); ?></td>
                                <td style="padding:12px 14px;border-bottom:1px solid #f1f5f9;color:#475569;text-align:right;">
                                    <?php echo e($meter->baseline_kwh !== null ? number_format((float) $meter->baseline_kwh, 2) : '-'); ?>

                                </td>
                                <td style="padding:12px 14px;border-bottom:1px solid #f1f5f9;color:#475569;max-width:260px;">
                                    <?php $reason = (string) ($meter->archive_reason ?? ''); ?>
                                    <span title="<?php echo e($reason); ?>"><?php echo e(\Illuminate\Support\Str::limit($reason !== '' ? $reason : '-', 60)); ?></span>
                                </td>
                                <td style="padding:12px 14px;border-bottom:1px solid #f1f5f9;color:#475569;">
                                    <?php echo e($meter->deletedByUser?->full_name ?? $meter->deletedByUser?->name ?? $meter->deletedByUser?->username ?? 'Unknown'); ?>

                                </td>
                                <td style="padding:12px 14px;border-bottom:1px solid #f1f5f9;color:#475569;">
                                    <?php echo e($meter->deleted_at?->format('M d, Y h:i A') ?? '-'); ?>

                                </td>
                                <td style="padding:12px 14px;border-bottom:1px solid #f1f5f9;text-align:center;">
                                    <div style="display:inline-flex;gap:8px;flex-wrap:wrap;justify-content:center;">
                                        <?php if($canManageMeters): ?>
                                            <form method="POST" action="<?php echo e(route('modules.facilities.meters.restore', [$facility->id, $meter->id])); ?>" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" style="background:#16a34a;color:#fff;border:none;border-radius:8px;padding:8px 12px;font-weight:700;"
                                                    onclick="return confirm('Restore meter ' + <?php echo \Illuminate\Support\Js::from($meter->meter_name)->toHtml() ?> + '?');">
                                                    Restore
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <?php if($canForceDeleteMeters): ?>
                                            <form method="POST" action="<?php echo e(route('modules.facilities.meters.force-delete', [$facility->id, $meter->id])); ?>" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" style="background:#e11d48;color:#fff;border:none;border-radius:8px;padding:8px 12px;font-weight:700;"
                                                    onclick="return confirm('Permanently delete meter ' + <?php echo \Illuminate\Support\Js::from($meter->meter_name)->toHtml() ?> + '?');">
                                                    Permanent Delete
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php if($archivedMeters->hasPages()): ?>
                <div style="padding:14px 16px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;border-top:1px solid #e5e7eb;background:#fcfdff;">
                    <div style="color:#64748b;">Showing <?php echo e($archivedMeters->firstItem()); ?> to <?php echo e($archivedMeters->lastItem()); ?> of <?php echo e($archivedMeters->total()); ?> archived meters</div>
                    <div style="display:flex;gap:8px;align-items:center;">
                        <?php if($archivedMeters->onFirstPage()): ?>
                            <span style="padding:8px 12px;border-radius:8px;background:#f1f5f9;color:#94a3b8;">Previous</span>
                        <?php else: ?>
                            <a href="<?php echo e($archivedMeters->previousPageUrl()); ?>" style="padding:8px 12px;border-radius:8px;background:#e2e8f0;color:#1e293b;text-decoration:none;font-weight:700;">Previous</a>
                        <?php endif; ?>
                        <span style="padding:8px 12px;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;">Page <?php echo e($archivedMeters->currentPage()); ?> / <?php echo e($archivedMeters->lastPage()); ?></span>
                        <?php if($archivedMeters->hasMorePages()): ?>
                            <a href="<?php echo e($archivedMeters->nextPageUrl()); ?>" style="padding:8px 12px;border-radius:8px;background:#e2e8f0;color:#1e293b;text-decoration:none;font-weight:700;">Next</a>
                        <?php else: ?>
                            <span style="padding:8px 12px;border-radius:8px;background:#f1f5f9;color:#94a3b8;">Next</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.qc-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\modules\facilities\meters\archive.blade.php ENDPATH**/ ?>