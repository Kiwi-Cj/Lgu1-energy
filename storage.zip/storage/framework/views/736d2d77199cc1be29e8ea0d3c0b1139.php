<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Contact | Energy System Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('img/logocityhall.jpg')); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f8fafc; color: #1f2937; }
        .navbar { background: rgba(255,255,255,0.98); box-shadow: 0 2px 12px rgba(0,0,0,0.06); }
        .navbar-brand img { height: 38px; margin-right: 10px; }
        .hero { background: linear-gradient(135deg, #0f766e, #14b8a6); color: #fff; padding: 64px 0 48px; }
        .contact-card { background: #fff; border-radius: 18px; box-shadow: 0 12px 28px rgba(0,0,0,0.06); padding: 28px; }
    </style>
</head>
<body>
<?php
    $supportEmail = env('ADMIN_SUPPORT_EMAIL', 'energyconservemgmt@gmail.com');
    $supportPhone = env('ADMIN_SUPPORT_PHONE', '+1 (555) 123-4567');
    $supportPhoneHref = preg_replace('/[^0-9+]/', '', $supportPhone);
    $contactUser = auth()->user();
    $prefillName = old('name', $contactUser?->full_name ?? $contactUser?->name ?? $contactUser?->username ?? '');
    $prefillEmail = old('email', $contactUser?->email ?? '');
?>

<nav class="navbar navbar-expand-lg navbar-light sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('img/logocityhall.jpg')); ?>" alt="Logo">
            <span class="fw-bold" style="font-size:1.1rem;">Energy System Portal</span>
        </a>
        <div class="d-flex gap-2">
            <a class="btn btn-outline-primary" href="<?php echo e(url('/')); ?>">Home</a>
            <a class="btn btn-primary" href="<?php echo e(url('/login')); ?>">Login</a>
        </div>
    </div>
</nav>

<section class="hero">
    <div class="container text-center">
        <h1 class="fw-bold mb-3">Contact Us</h1>
        <p class="mb-0">Send your concerns and inquiries to the Energy System Portal support team.</p>
    </div>
</section>

<section class="py-5" id="contact">
    <div class="container">
        <div class="row g-4 justify-content-center">
            <div class="col-lg-7">
                <div class="contact-card">
                    <h2 class="h4 mb-3">Get in Touch</h2>
                    <p class="text-muted mb-4">Have a concern or inquiry? Send us a message and our team will respond as soon as possible.</p>
                    <?php if(session('contact_success')): ?>
                        <div class="alert alert-success"><?php echo e(session('contact_success')); ?></div>
                    <?php endif; ?>
                    <?php if(session('contact_warning')): ?>
                        <div class="alert alert-warning"><?php echo e(session('contact_warning')); ?></div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">Please review the highlighted fields and try again.</div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('landing.contact.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold mb-1">Full Name</label>
                                <input type="text" name="name" value="<?php echo e($prefillName); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="e.g. Juan Dela Cruz" required>
                                <div class="form-text text-start">Use your personal full name, not office/facility name.</div>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold mb-1">Email Address</label>
                                <input type="email" name="email" value="<?php echo e($prefillEmail); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="name@example.com" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold mb-1">Subject (Optional)</label>
                                <input type="text" name="subject" value="<?php echo e(old('subject')); ?>" class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="e.g. Police Station 12 concern">
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold mb-1">Message</label>
                                <textarea name="message" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="4" placeholder="Your Message" required><?php echo e(old('message')); ?></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12 d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">Send Message</button>
                            </div>
                        </div>
                    </form>
                    <div class="mt-4 text-muted">
                        <div>Email: <a href="mailto:<?php echo e($supportEmail); ?>"><?php echo e($supportEmail); ?></a></div>
                        <div>Phone: <a href="tel:<?php echo e($supportPhoneHref); ?>"><?php echo e($supportPhone); ?></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\landing\contact.blade.php ENDPATH**/ ?>