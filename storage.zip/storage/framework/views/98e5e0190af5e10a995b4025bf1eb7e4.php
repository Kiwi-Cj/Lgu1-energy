

<?php $__env->startSection('title','Facility Details'); ?>

<?php $__env->startSection('content'); ?>
<?php
	$user = auth()->user();
?>

<?php if(session('success')): ?>
<div id="successAlert" style="position:fixed;top:32px;right:32px;z-index:99999;min-width:280px;max-width:420px;">
    <div style="background:#dcfce7;color:#166534;padding:16px 24px;border-radius:12px;font-weight:700;font-size:1.08rem;box-shadow:0 2px 8px #16a34a22;display:flex;align-items:center;gap:10px;">
        <i class="fa fa-check-circle" style="color:#22c55e;font-size:1.3rem;"></i>
        <span><?php echo e(session('success')); ?></span>
    </div>
</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div id="errorAlert" style="position:fixed;top:32px;right:32px;z-index:99999;min-width:280px;max-width:420px;">
    <div style="background:#fee2e2;color:#b91c1c;padding:16px 24px;border-radius:12px;font-weight:700;font-size:1.08rem;box-shadow:0 2px 8px #e11d4822;display:flex;align-items:center;gap:10px;">
        <i class="fa fa-times-circle" style="color:#e11d48;font-size:1.3rem;"></i>
        <span><?php echo e(session('error')); ?></span>
    </div>
</div>
<?php endif; ?>
<script>
window.addEventListener('DOMContentLoaded', function() {
        var success = document.getElementById('successAlert');
        var error = document.getElementById('errorAlert');
        if (success) setTimeout(() => success.style.display = 'none', 3000);
        if (error) setTimeout(() => error.style.display = 'none', 3000);
});
</script>

<style>
body.dark-mode .facility-show-page .facility-show-shell {
    background: linear-gradient(145deg, #0f172a, #111827) !important;
    box-shadow: 0 14px 34px rgba(2, 6, 23, 0.6);
}

body.dark-mode .facility-show-page [style*="background:#fff"],
body.dark-mode .facility-show-page [style*="background: #fff"],
body.dark-mode .facility-show-page [style*="background:#ffffff"],
body.dark-mode .facility-show-page [style*="background: #ffffff"],
body.dark-mode .facility-show-page [style*="background:#f8fafc"],
body.dark-mode .facility-show-page [style*="background: #f8fafc"],
body.dark-mode .facility-show-page [style*="background:#f1f5f9"],
body.dark-mode .facility-show-page [style*="background: #f1f5f9"],
body.dark-mode .facility-show-page [style*="background:#e0f2fe"],
body.dark-mode .facility-show-page [style*="background: #e0f2fe"] {
    background: #111827 !important;
    border-color: #334155 !important;
}

body.dark-mode .facility-show-page [style*="color:#222"],
body.dark-mode .facility-show-page [style*="color: #222"],
body.dark-mode .facility-show-page [style*="color:#1e293b"],
body.dark-mode .facility-show-page [style*="color: #1e293b"],
body.dark-mode .facility-show-page [style*="color:#475569"],
body.dark-mode .facility-show-page [style*="color: #475569"],
body.dark-mode .facility-show-page [style*="color:#64748b"],
body.dark-mode .facility-show-page [style*="color: #64748b"],
body.dark-mode .facility-show-page [style*="color:#9ca3af"],
body.dark-mode .facility-show-page [style*="color: #9ca3af"] {
    color: #e2e8f0 !important;
}

body.dark-mode .facility-show-page [style*="color:#2563eb"],
body.dark-mode .facility-show-page [style*="color: #2563eb"],
body.dark-mode .facility-show-page [style*="color:#0ea5e9"],
body.dark-mode .facility-show-page [style*="color: #0ea5e9"] {
    color: #93c5fd !important;
}

body.dark-mode .facility-show-page .energy-profile-details-card,
body.dark-mode .facility-show-page .energy-performance-card {
    background: #0f172a !important;
    border: 1px solid #334155;
    box-shadow: 0 12px 28px rgba(2, 6, 23, 0.55);
    color: #e2e8f0 !important;
}

body.dark-mode .facility-show-page .energy-profile-details-card h3,
body.dark-mode .facility-show-page .energy-performance-card h3 {
    color: #93c5fd !important;
}

body.dark-mode .facility-show-page .energy-profile-empty {
    color: #cbd5e1 !important;
}

body.dark-mode .facility-show-page .energy-warning {
    color: #fda4af !important;
}

.facility-show-page-container {
    width: 100%;
    margin: 40px 0;
}

.facility-show-shell {
    background: linear-gradient(135deg, #f8fafc, #eef2ff);
    border-radius: 26px;
    padding: 40px;
    box-shadow: 0 12px 40px rgba(37, 99, 235, .18);
    position: relative;
    width: 100%;
}

.facility-back-btn {
    position: absolute;
    left: 28px;
    top: -22px;
    background: #fff;
    padding: 10px 22px;
    border-radius: 14px;
    font-weight: 800;
    color: #2563eb;
    text-decoration: none;
    box-shadow: 0 4px 16px #2563eb33;
}

.facility-header {
    display: flex;
    gap: 28px;
    align-items: center;
    margin-bottom: 30px;
}

.facility-hero-image {
    width: 160px;
    height: 120px;
    border-radius: 18px;
    object-fit: cover;
    box-shadow: 0 6px 20px rgba(0, 0, 0, .2);
}

.facility-hero-image-placeholder {
    width: 160px;
    height: 120px;
    border-radius: 18px;
    background: #e5e7eb;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    color: #9ca3af;
}

.facility-header-main {
    flex: 1;
}

.facility-title {
    margin: 0;
    font-size: 2.2rem;
    font-weight: 900;
    color: #1e293b;
}

.facility-subtitle {
    color: #6366f1;
    font-weight: 700;
    margin-top: 6px;
}

.facility-edit-btn {
    margin-top: 18px;
    background: #2563eb;
    color: #fff;
    padding: 8px 22px;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    font-size: 1.05rem;
    cursor: pointer;
}

.facility-pill-row {
    display: flex;
    gap: 10px;
    margin-top: 12px;
    flex-wrap: wrap;
}

.facility-pill {
    padding: 6px 18px;
    border-radius: 999px;
    font-weight: 800;
    font-size: .9rem;
}

.facility-pill.status-active {
    background: #dcfce7;
    color: #166534;
}

.facility-pill.status-maintenance {
    background: #fef3c7;
    color: #92400e;
}

.facility-pill.status-inactive {
    background: #fee2e2;
    color: #991b1b;
}

.facility-pill.main {
    background: #eff6ff;
    color: #1d4ed8;
}

.facility-pill.sub {
    background: #f3e8ff;
    color: #7c3aed;
}

.facility-pill.approved {
    background: #ecfeff;
    color: #0f766e;
}

.facility-pill.primary {
    background: #f1f5f9;
    color: #334155;
}

.facility-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 18px;
    margin-top: 24px;
}

.facility-info-card {
    background: #fff;
    padding: 18px;
    border-radius: 16px;
    display: flex;
    gap: 14px;
    box-shadow: 0 6px 18px rgba(0, 0, 0, .08);
}

.facility-info-icon {
    width: 44px;
    height: 44px;
    border-radius: 14px;
    background: #2563eb1a;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    color: #2563eb;
}

.facility-info-label {
    font-size: .85rem;
    color: #64748b;
    font-weight: 700;
}

.facility-info-value {
    font-size: 1.05rem;
    font-weight: 800;
    color: #1e293b;
}

.facility-action-row {
    display: flex;
    gap: 14px;
    justify-content: flex-end;
    margin-top: 30px;
    flex-wrap: wrap;
}

.facility-action-link,
.facility-action-btn {
    color: #fff;
    padding: 12px 26px;
    border: none;
    border-radius: 999px;
    font-weight: 800;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
}

.facility-action-link.records {
    background: #0f766e;
}

.facility-action-link.submeters {
    background: #7c3aed;
}

.facility-action-link.profile {
    background: #2563eb;
}

.facility-action-btn.archive {
    background: #e11d48;
}

body.dark-mode .facility-show-page .facility-back-btn,
body.dark-mode .facility-show-page .facility-info-card,
body.dark-mode .facility-show-page .facility-pill.primary {
    background: #111827 !important;
    border-color: #334155 !important;
    color: #e2e8f0 !important;
}

body.dark-mode .facility-show-page .facility-title,
body.dark-mode .facility-show-page .facility-info-value {
    color: #e2e8f0 !important;
}
</style>

<div class="facility-show-page facility-show-page-container">
<div class="facility-show-shell">

<!-- BACK BUTTON -->
<a href="<?php echo e(route('modules.facilities.index')); ?>" class="facility-back-btn">
<i class="fa fa-arrow-left" style="margin-right:6px;"></i> Back
</a>


<?php
$imageUrl = $facility->resolved_image_url;
$profile = $facility->energyProfiles()->with('primaryMeter')->latest()->first();
$mainMeters = $facility->meters()->where('meter_type', 'main')->whereNotNull('approved_at')->get();
$subMeters = $facility->meters()->where('meter_type', 'sub')->whereNotNull('approved_at')->get();
$activeApprovedMainMeters = $mainMeters->filter(fn ($meter) => strtolower((string) $meter->status) === 'active');
$allMeters = $mainMeters->concat($subMeters);
$approvedMeterCount = $allMeters->filter(fn ($meter) => !empty($meter->approved_at))->count();
$totalMeterCount = $mainMeters->count() + $subMeters->count();
$primaryMainMeter = ($profile?->primaryMeter && !empty($profile->primaryMeter->approved_at)) ? $profile->primaryMeter : null;
?>

<!-- HEADER -->
<div class="facility-header">
<?php if($imageUrl): ?>
<img src="<?php echo e($imageUrl); ?>" class="facility-hero-image">
<?php else: ?>
<div class="facility-hero-image-placeholder">
<i class="fa fa-image"></i>
</div>
<?php endif; ?>

<div class="facility-header-main">
<h1 class="facility-title">
	<?php echo e($facility->name); ?>

</h1>
<div class="facility-subtitle">
	<?php echo e($facility->type); ?> &bull; <?php echo e($facility->department); ?>

</div>
<?php if(!in_array((auth()->user()?->role_key ?? str_replace(' ', '_', strtolower((string) (auth()->user()?->role ?? '')))), ['staff', 'energy_officer'], true)): ?>
<button type="button" onclick="openEditFacilityModal()" class="facility-edit-btn">
	<i class="fa fa-edit" style="margin-right:6px;"></i> Edit Facility
</button>
<?php endif; ?>

<?php
	$statusClass = $facility->status === 'active' ? 'status-active' : ($facility->status === 'maintenance' ? 'status-maintenance' : 'status-inactive');
?>
<div class="facility-pill-row">
<span class="facility-pill <?php echo e($statusClass); ?>">
<?php echo e(ucfirst($facility->status)); ?>

</span>

<span class="facility-pill main">
Main Meters: <?php echo e($mainMeters->count()); ?>

</span>

<span class="facility-pill sub">
Sub-meters: <?php echo e($subMeters->count()); ?>

</span>

<span class="facility-pill approved">
Approved Meters: <?php echo e($approvedMeterCount); ?> / <?php echo e($totalMeterCount); ?>

</span>

</div>
</div>
</div>


<!-- DETAILS GRID -->
<div class="facility-info-grid">

<?php
// Facility size is based on total approved + active MAIN meter baseline.
$baselineForSize = (float) $activeApprovedMainMeters->sum(function ($meter) {
	return (is_numeric($meter->baseline_kwh) && (float) $meter->baseline_kwh > 0)
		? (float) $meter->baseline_kwh
		: 0;
});
$sizeLabel = '-';

if ($baselineForSize <= 0) {
	$baselineForSize = null;
}

if ($baselineForSize !== null) {
	$sizeLabel = \App\Models\Facility::resolveSizeLabelFromBaseline($baselineForSize) ?? '-';
}
?>

<?php $__currentLoopData = [
	['<i class="fa fa-map-marker"></i>','Address',$facility->address],
	['<i class="fa fa-map"></i>','Barangay',$facility->barangay],
	['<i class="fa fa-expand"></i>','Floor Area',$facility->floor_area.' sqm'],
	['<i class="fa fa-building"></i>','Floors',$facility->floors],
	['<i class="fa fa-calendar"></i>','Year Built',$facility->year_built],
	['<i class="fa fa-clock-o"></i>','Operating Hours',$facility->operating_hours],
	['<i class="fa fa-bar-chart"></i>','Facility Size',$sizeLabel]
]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="facility-info-card">
		<div class="facility-info-icon">
			<?php echo $info[0]; ?>

		</div>
		<div>
			<div class="facility-info-label"><?php echo e($info[1]); ?></div>
			<div class="facility-info-value"><?php echo e($info[2] ?: '-'); ?></div>
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<!-- ENERGY PROFILE DETAILS -->
<div class="energy-profile-details-card" style="margin-top:32px;padding:26px 32px;border-radius:22px;background:linear-gradient(135deg,#f8fafc,#e0f2fe);box-shadow:0 8px 28px rgba(37,99,235,.10);">
	<h3 style="margin:0 0 18px;font-weight:900;color:#0ea5e9;font-size:1.18rem;display:flex;align-items:center;gap:8px;">
		<i class="fa fa-id-card"></i> Energy Profile Details
	</h3>
	<?php if($profile): ?>
		<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px;">
			<div><span style="color:#64748b;font-weight:700;">Electric Meter No:</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e($profile->electric_meter_no ?? '-'); ?></span></div>
			<div><span style="color:#64748b;font-weight:700;">Utility Provider:</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e($profile->utility_provider ?? '-'); ?></span></div>
			<div><span style="color:#64748b;font-weight:700;">Contract Account No:</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e($profile->contract_account_no ?? '-'); ?></span></div>
			<div><span style="color:#64748b;font-weight:700;">Baseline kWh:</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e(is_numeric($profile->baseline_kwh) ? number_format((float) $profile->baseline_kwh, 2) : '-'); ?></span></div>
			<div><span style="color:#64748b;font-weight:700;">Main Energy Source:</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e($profile->main_energy_source ?? '-'); ?></span></div>
			<div><span style="color:#64748b;font-weight:700;">Backup Power:</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e($profile->backup_power ?? '-'); ?></span></div>
			<div><span style="color:#64748b;font-weight:700;">Transformer Capacity:</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e($profile->transformer_capacity ?? '-'); ?></span></div>
			<div><span style="color:#64748b;font-weight:700;">Number of Meters (Profile):</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e($profile->number_of_meters ?? '-'); ?></span></div>
			<div><span style="color:#64748b;font-weight:700;">Number of Meters (Actual):</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e($totalMeterCount); ?></span></div>
			<div><span style="color:#64748b;font-weight:700;">Baseline Source:</span><br><span style="font-weight:800;color:#1e293b;"><?php echo e($profile->baseline_source ?? '-'); ?></span></div>
			<?php if($profile->bill_image): ?>
				<div><span style="color:#64748b;font-weight:700;">Bill Image:</span><br><img src="<?php echo e(asset('storage/'.$profile->bill_image)); ?>" alt="Bill Image" style="max-width:120px;border-radius:8px;box-shadow:0 2px 8px #2563eb22;"></div>
			<?php endif; ?>
		</div>
	<?php else: ?>
		<div class="energy-profile-empty" style="color:#64748b;font-weight:700;">No energy profile data available for this facility.</div>
	<?php endif; ?>
</div>

<!-- ENERGY SUMMARY -->
<?php
	$baselineKwh = (float) $activeApprovedMainMeters->sum(function ($meter) {
		return (is_numeric($meter->baseline_kwh) && (float) $meter->baseline_kwh > 0)
			? (float) $meter->baseline_kwh
			: 0;
	});
	$baselineSource = 'Total Main Meter Baseline';

	$hasBaseline = $baselineKwh > 0;
?>

<?php if($hasBaseline): ?>
<div class="energy-performance-card" style="margin-top:32px;padding:26px;border-radius:22px;background:linear-gradient(135deg,#eff6ff,#ffffff);box-shadow:0 10px 30px rgba(37,99,235,.15);">
	<h3 style="margin:0 0 14px;font-weight:900;color:#2563eb;">
		<i class="fa fa-bolt" style="margin-right:6px;"></i> Energy Performance
	</h3>
	<div style="font-size:1.7rem;font-weight:900;color:#2563eb;">
		<?php echo e(number_format($baselineKwh,2)); ?> kWh
	</div>
	<div style="font-size:.9rem;color:#475569;">
		Baseline consumption (<?php echo e($baselineSource); ?>)
	</div>
</div>
<?php else: ?>
<div class="energy-performance-card" style="margin-top:32px;padding:26px;border-radius:22px;background:linear-gradient(135deg,#eff6ff,#ffffff);box-shadow:0 10px 30px rgba(37,99,235,.15);">
	<h3 style="margin:0 0 14px;font-weight:900;color:#2563eb;">
		<i class="fa fa-bolt" style="margin-right:6px;"></i> Energy Performance
	</h3>
	<div class="energy-warning" style="color:#b91c1c;font-weight:700;">
		<i class="fa fa-exclamation-triangle" style="margin-right:6px;"></i> Insufficient data (no baseline in approved active main meters)
	</div>
</div>
<?php endif; ?>


<!-- ACTIONS -->
<div class="facility-action-row">
	<!-- Edit Facility button removed -->
	<a href="<?php echo e(route('facilities.monthly-records', ['facility' => $facility->id, 'record_scope' => 'main'])); ?>" class="facility-action-link records">
		<i class="fa fa-chart-line" style="margin-right:6px;"></i> Monthly Records
	</a>
	<a href="<?php echo e(route('facilities.monthly-records.submeters', $facility->id)); ?>" class="facility-action-link submeters">
		<i class="fa fa-network-wired" style="margin-right:6px;"></i> Sub-meter Records
	</a>
	<a href="<?php echo e(route('modules.facilities.energy-profile.index', $facility->id)); ?>" class="facility-action-link profile">
		<i class="fa fa-bolt" style="margin-right:6px;"></i> Energy Profile
	</a>
	<?php if(!in_array((auth()->user()?->role_key ?? str_replace(' ', '_', strtolower((string) (auth()->user()?->role ?? '')))), ['staff', 'energy_officer'], true)): ?>
	<button type="button" onclick="openDeleteFacilityModal(<?php echo e($facility->id); ?>, '<?php echo e(route('facilities.destroy', $facility->id)); ?>')" class="facility-action-btn archive"><i class="fa fa-box-archive" style="margin-right:6px;"></i> Delete</button>
	<?php endif; ?>
</div>

</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('modules.facilities.partials.modals', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
function openEditFacilityModal() {
	var facility = <?php echo json_encode($facility, 15, 512) ?>;
	document.getElementById('edit_facility_id').value = facility.id || '';
	document.getElementById('edit_name').value = facility.name || '';
	document.getElementById('edit_type').value = facility.type || '';
	document.getElementById('edit_department').value = facility.department || '';
	document.getElementById('edit_address').value = facility.address || '';
	document.getElementById('edit_barangay').value = facility.barangay || '';
	document.getElementById('edit_floor_area').value = facility.floor_area || '';
	document.getElementById('edit_floors').value = facility.floors || '';
	document.getElementById('edit_year_built').value = facility.year_built || '';
	document.getElementById('edit_operating_hours').value = facility.operating_hours || '';
	document.getElementById('edit_status').value = facility.status || '';
	// Set form action dynamically
	document.getElementById('editFacilityForm').action = '/facilities/' + facility.id;
	// Image preview
	var preview = document.getElementById('edit_image_preview');
	var imagePath = facility.image_path || facility.image || '';
	if (imagePath) {
		let imageUrl = '';
		if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
			imageUrl = imagePath;
		} else if (imagePath.startsWith('img/') || imagePath.startsWith('uploads/') || imagePath.startsWith('storage/')) {
			imageUrl = '/' + imagePath;
		} else {
			imageUrl = '/storage/' + imagePath;
		}
		preview.innerHTML = '<img src="' + imageUrl + '" style="max-width:100%;max-height:120px;border-radius:10px;">';
	} else {
		preview.innerHTML = '<div style="width:100%;height:80px;background:#f1f5f9;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:2rem;"><i class="fa fa-image"></i></div>';
	}
	document.getElementById('editFacilityModal').style.display = 'flex';
}
</script>

<?php echo $__env->make('layouts.qc-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\modules\facilities\show.blade.php ENDPATH**/ ?>