<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Password</title>
</head>
<body>
    <?php echo $__env->make('layouts.partials.flash-toast', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <h1>Confirm Password</h1>
    <p>Please confirm your password before continuing.</p>

    <?php if($errors->any()): ?>
        <div>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('password.confirm')); ?>">
        <?php echo csrf_field(); ?>
        <label for="password">Password</label>
        <input id="password" type="password" name="password" required>
        <button type="submit">Confirm</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\auth\confirm-password.blade.php ENDPATH**/ ?>