<?php $__env->startSection('title', 'Load Tracking'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $totals = $totals ?? ['total_watts' => 0, 'estimated_kwh' => 0, 'actual_kwh' => 0, 'variance_percent' => null, 'flagged_submeters' => 0];
    $rows = $rows ?? collect();
    $topEquipment = $topEquipment ?? collect();
    $pieLabels = $pieLabels ?? [];
    $pieValues = $pieValues ?? [];
    $comparisonLabels = $comparisonLabels ?? [];
    $comparisonEstimated = $comparisonEstimated ?? [];
    $comparisonActual = $comparisonActual ?? [];
    $varianceThreshold = $varianceThreshold ?? 20;
    $warningThreshold = $warningThreshold ?? 10;
    $mainMeters = $mainMeters ?? collect();
    $submeters = $submeters ?? collect();
    $selectedMeterScope = $selectedMeterScope ?? 'all';
    $selectedConsumptionFilter = $selectedConsumptionFilter ?? 'all';
?>

<style>
    .lt-filter-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
        gap: 10px;
        align-items: end;
    }
    .lt-filter-field { display: grid; gap: 6px; }
    .lt-filter-label { font-size: .8rem; font-weight: 700; color: #475569; }
    .lt-control {
        width: 100%;
        padding: 9px 12px;
        border: 1px solid #cbd5e1;
        border-radius: 12px;
        background: #fff;
        color: #0f172a;
    }
    .lt-control:focus {
        outline: none;
        border-color: #60a5fa;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, .14);
    }
    .lt-filter-actions { display: flex; gap: 8px; }
    .lt-btn {
        text-decoration: none;
        border-radius: 12px;
        padding: 10px 14px;
        font-weight: 700;
        border: 1px solid transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
    .lt-btn.apply { background: #1d4ed8; color: #fff; }
    .lt-btn.reset { background: #f1f5f9; color: #334155; border-color: #e2e8f0; }

    .lt-data-table {
        width: 100%;
        min-width: 1140px;
        border-collapse: separate;
        border-spacing: 0;
        table-layout: fixed;
    }

    .lt-data-table thead th {
        padding: 10px 10px !important;
        text-align: center !important;
        text-transform: uppercase;
        letter-spacing: .05em;
        font-size: .74rem;
        color: #475569;
        font-weight: 800;
        background: #f8fafc !important;
        border-bottom: 1px solid #dbe4f2 !important;
    }

    .lt-data-table td {
        padding: 10px 10px !important;
        text-align: center !important;
        border-top: 1px solid #edf2f7 !important;
        font-size: .94rem;
    }

    .lt-data-table td span[style*="border-radius:999px"] {
        padding: 4px 10px !important;
        font-size: .73rem !important;
    }
</style>

<div class="em-page">
    <?php if(session('success')): ?>
        <div style="margin-bottom:12px;background:#dcfce7;color:#166534;padding:12px 16px;border-radius:12px;font-weight:700;"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div style="margin-bottom:12px;background:#fee2e2;color:#b91c1c;padding:12px 16px;border-radius:12px;font-weight:700;"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div style="margin-bottom:12px;background:#fff7ed;color:#9a3412;padding:12px 16px;border-radius:12px;font-weight:700;">Please check the form fields and try again.</div>
    <?php endif; ?>

    <div class="em-header">
        <div>
            <h2>Main/Sub Meter Load Tracking</h2>
            <div class="em-header-subtitle">Track watts and estimated kWh per equipment under Sub Meters and Main Meters.</div>
        </div>
        <div class="em-header-actions">
            <a href="<?php echo e(route('modules.facilities.index')); ?>" class="em-action-btn soft">Facility Equipment Inventory</a>
        </div>
    </div>

    <div class="em-panel" style="padding:12px;">
        <form method="GET" action="<?php echo e(route('modules.load-tracking.index')); ?>" class="lt-filter-grid">
            <div class="lt-filter-field">
                <label class="lt-filter-label">Month</label>
                <input type="month" name="month" value="<?php echo e($selectedMonth); ?>" class="lt-control">
            </div>
            <div class="lt-filter-field">
                <label class="lt-filter-label">Facility</label>
                <select name="facility_id" class="lt-control">
                    <option value="">All Facilities</option>
                    <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($facility->id); ?>" <?php if((string) $selectedFacility === (string) $facility->id): echo 'selected'; endif; ?>><?php echo e($facility->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="lt-filter-field">
                <label class="lt-filter-label">Meter Scope</label>
                <select id="filter_meter_scope" name="meter_scope" class="lt-control">
                    <option value="all" <?php if($selectedMeterScope === 'all'): echo 'selected'; endif; ?>>All</option>
                    <option value="sub" <?php if($selectedMeterScope === 'sub'): echo 'selected'; endif; ?>>Sub Meter</option>
                    <option value="main" <?php if($selectedMeterScope === 'main'): echo 'selected'; endif; ?>>Main Meter</option>
                </select>
            </div>
            <div class="lt-filter-field">
                <label class="lt-filter-label">Consumption</label>
                <select name="consumption_filter" class="lt-control">
                    <option value="all" <?php if($selectedConsumptionFilter === 'all'): echo 'selected'; endif; ?>>All Levels</option>
                    <option value="warning_high" <?php if($selectedConsumptionFilter === 'warning_high'): echo 'selected'; endif; ?>>Warning + High Only</option>
                </select>
            </div>
            <div id="filter_sub_group" class="lt-filter-field">
                <label class="lt-filter-label">Sub Meter</label>
                <select name="submeter_id" class="lt-control">
                    <option value="">All Sub Meters</option>
                    <?php $__currentLoopData = $submeters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($submeter->id); ?>" <?php if((string) $selectedSubmeter === (string) $submeter->id): echo 'selected'; endif; ?>><?php echo e($submeter->submeter_name); ?> (<?php echo e($submeter->facility?->name ?? 'Facility'); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div id="filter_main_group" class="lt-filter-field">
                <label class="lt-filter-label">Main Meter</label>
                <select name="main_meter_id" class="lt-control">
                    <option value="">All Main Meters</option>
                    <?php $__currentLoopData = $mainMeters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainMeter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mainMeter->id); ?>" <?php if((string) $selectedMainMeter === (string) $mainMeter->id): echo 'selected'; endif; ?>><?php echo e($mainMeter->meter_name); ?> (<?php echo e($mainMeter->facility?->name ?? 'Facility'); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="lt-filter-actions">
                <button type="submit" class="lt-btn apply">Apply</button>
                <a href="<?php echo e(route('modules.load-tracking.index')); ?>" class="lt-btn reset">Reset</a>
            </div>
        </form>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;">
        <div style="background:#fff;border:1px solid #c7d2fe;border-radius:12px;padding:12px;"><div style="font-size:.78rem;color:#4338ca;font-weight:800;">TOTAL WATTS</div><div style="font-size:1.45rem;font-weight:900;"><?php echo e(number_format((float) ($totals['total_watts'] ?? 0), 2)); ?></div></div>
        <div style="background:#fff;border:1px solid #dbeafe;border-radius:12px;padding:12px;"><div style="font-size:.78rem;color:#1e40af;font-weight:800;">TOTAL ESTIMATED KWH</div><div style="font-size:1.45rem;font-weight:900;"><?php echo e(number_format((float) $totals['estimated_kwh'], 2)); ?></div></div>
        <div style="background:#fff;border:1px solid #bae6fd;border-radius:12px;padding:12px;"><div style="font-size:.78rem;color:#0f766e;font-weight:800;">TOTAL ACTUAL KWH</div><div style="font-size:1.45rem;font-weight:900;"><?php echo e(number_format((float) $totals['actual_kwh'], 2)); ?></div></div>
        <div style="background:#fff;border:1px solid #fde68a;border-radius:12px;padding:12px;"><div style="font-size:.78rem;color:#92400e;font-weight:800;">TOTAL VARIANCE %</div><div style="font-size:1.45rem;font-weight:900;"><?php echo e($totals['variance_percent'] !== null ? number_format((float) $totals['variance_percent'], 2).'%' : '-'); ?></div></div>
        <div style="background:#fff;border:1px solid #fecaca;border-radius:12px;padding:12px;"><div style="font-size:.78rem;color:#991b1b;font-weight:800;">FLAGGED METERS (&gt; <?php echo e(number_format((float) $varianceThreshold, 0)); ?>%)</div><div style="font-size:1.45rem;font-weight:900;color:#991b1b;"><?php echo e(number_format((int) $totals['flagged_submeters'])); ?></div></div>
    </div>

    <div class="em-panel" style="padding:10px 12px;color:#475569;font-size:.84rem;">
        <strong style="color:#1e293b;">How to read this table:</strong>
        Main Meter is the parent source. Sub Meter rows show the linked main meter when mapped. Compare Estimated kWh vs Actual kWh: Warning is over <?php echo e(number_format((float) $warningThreshold, 0)); ?>%, High is over <?php echo e(number_format((float) $varianceThreshold, 0)); ?>%, and No Estimate means actual usage exists but equipment inventory is incomplete.
    </div>

    <div class="em-panel em-table-wrap">
        <table class="lt-data-table">
            <thead>
                <tr style="background:#f8fafc;">
                    <th style="text-align:center;">Tier</th>
                    <th style="text-align:left;">Facility</th>
                    <th style="text-align:left;">Type</th>
                    <th style="text-align:left;">Linked Main</th>
                    <th style="text-align:left;">Meter</th>
                    <th style="text-align:center;">Equipment</th>
                    <th style="text-align:right;">Total Watts</th>
                    <th style="text-align:right;">Estimated kWh</th>
                    <th style="text-align:right;">Actual kWh</th>
                    <th style="text-align:center;">Variance %</th>
                    <th style="text-align:center;">Alert Level</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $facilityLabel = trim((string) ($row['facility_name'] ?? '')) !== ''
                            ? (string) $row['facility_name']
                            : 'Unknown Facility';
                        $level = strtolower((string) ($row['consumption_level'] ?? 'normal'));
                        $pillBg = $level === 'high'
                            ? '#fee2e2'
                            : ($level === 'warning' ? '#fffbeb' : ($level === 'no_estimate' ? '#eff6ff' : '#f1f5f9'));
                        $pillColor = $level === 'high'
                            ? '#b91c1c'
                            : ($level === 'warning' ? '#a16207' : ($level === 'no_estimate' ? '#1d4ed8' : '#334155'));
                        $pillBorder = $level === 'high'
                            ? '#fecaca'
                            : ($level === 'warning' ? '#fde68a' : ($level === 'no_estimate' ? '#bfdbfe' : '#cbd5e1'));
                        $rowBg = $level === 'high'
                            ? '#fff7f7'
                            : ($level === 'warning' ? '#fffdf2' : ($level === 'no_estimate' ? '#f8fbff' : '#ffffff'));
                    ?>
                    <tr style="background:<?php echo e($rowBg); ?>;">
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;text-align:center;font-weight:900;color:#1d4ed8;">
                            Top <?php echo e($loop->iteration); ?>

                        </td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;"><?php echo e($facilityLabel); ?></td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;"><?php echo e($row['meter_scope_label']); ?></td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;">
                            <?php echo e($row['parent_main_meter_name'] ?? ($row['meter_scope'] === 'main' ? 'Parent' : 'Unmapped')); ?>

                        </td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;font-weight:700;"><?php echo e($row['meter_name']); ?></td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;text-align:center;"><?php echo e(number_format((int) $row['equipment_count'])); ?></td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;text-align:right;"><?php echo e(number_format((float) ($row['total_watts'] ?? 0), 2)); ?></td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;text-align:right;color:#1d4ed8;font-weight:700;"><?php echo e(number_format((float) $row['estimated_kwh'], 2)); ?></td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;text-align:right;font-weight:700;"><?php echo e(number_format((float) $row['actual_kwh'], 2)); ?></td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;text-align:center;"><?php echo e($row['variance_percent'] !== null ? number_format((float) $row['variance_percent'], 2).'%' : '-'); ?></td>
                        <td style="padding:10px 12px;border-top:1px solid #f1f5f9;text-align:center;">
                            <span style="display:inline-flex;align-items:center;border-radius:999px;padding:2px 9px;font-size:.74rem;font-weight:800;background:<?php echo e($pillBg); ?>;color:<?php echo e($pillColor); ?>;border:1px solid <?php echo e($pillBorder); ?>;">
                                <?php echo e($row['consumption_label'] ?? 'Normal'); ?>

                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="11" style="padding:16px;text-align:center;color:#64748b;">
                        <?php echo e($selectedConsumptionFilter === 'warning_high'
                            ? 'No warning/high consumption meter found for selected filters. Meters with "No Estimate" are excluded in this view.'
                            : 'No meter data available for selected filters.'); ?>

                    </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:14px;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;">
        <div style="color:#1e3a8a;font-weight:700;">
            <i class="fa fa-cubes" style="margin-right:6px;"></i>
            Equipment Inventory is now under Facilities. Open a facility card and click the Equipment Inventory icon.
        </div>
        <?php if($selectedFacility): ?>
            <a href="<?php echo e(route('modules.facilities.equipment-inventory', $selectedFacility)); ?>" style="text-decoration:none;background:#1d4ed8;color:#fff;border-radius:10px;padding:9px 12px;font-weight:700;">
                Open Selected Facility Inventory
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('modules.facilities.index')); ?>" style="text-decoration:none;background:#1d4ed8;color:#fff;border-radius:10px;padding:9px 12px;font-weight:700;">
                Open Facilities
            </a>
        <?php endif; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var filterScope = document.getElementById('filter_meter_scope');
    var filterSub = document.getElementById('filter_sub_group');
    var filterMain = document.getElementById('filter_main_group');

    function toggleFilterGroups() {
        if (!filterScope) return;
        var scope = String(filterScope.value || 'all');
        if (filterSub) filterSub.style.display = scope === 'main' ? 'none' : 'block';
        if (filterMain) filterMain.style.display = scope === 'sub' ? 'none' : 'block';
    }

    filterScope?.addEventListener('change', toggleFilterGroups);
    toggleFilterGroups();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.qc-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\modules\load-tracking\index.blade.php ENDPATH**/ ?>