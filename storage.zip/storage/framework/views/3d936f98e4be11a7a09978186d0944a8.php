<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Email</title>
</head>
<body>
    <?php echo $__env->make('layouts.partials.flash-toast', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <h1>Verify Email</h1>
    <p>Please verify your email address by clicking the link we sent you.</p>

    <?php if(session('status') == 'verification-link-sent'): ?>
        <p>A new verification link has been sent to your email address.</p>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit">Resend Verification Email</button>
    </form>

    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit">Log Out</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\auth\verify-email.blade.php ENDPATH**/ ?>