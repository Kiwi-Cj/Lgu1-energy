<?php $__env->startSection('title', 'Energy Actions'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $facilityId = request('facility');
    $filteredActions = $facilityId ? $actions->where('facility_id', $facilityId) : $actions;
    $facilityName = null;
    if ($facilityId && $filteredActions->count() > 0) {
        $facilityName = $filteredActions->first()->facility->name ?? null;
    }
?>
// File removed
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.qc-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\modules\energy-actions\index.blade.php ENDPATH**/ ?>