<table>
    <thead>
        <tr>
            <th>Facility</th>
            <th>Month/Year</th>
            <th>Date Detected</th>
            <th>Status</th>
            <th>Severity</th>
            <th>Deviation</th>
            <th>Description</th>
            <th>Probable Cause</th>
            <th>Immediate Action</th>
            <th>Resolution</th>
            <th>Preventive Recommendation</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $incidentRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row['facility']); ?></td>
                <td><?php echo e($row['period']); ?></td>
                <td><?php echo e($row['date_detected']); ?></td>
                <td><?php echo e($row['status']); ?></td>
                <td><?php echo e($row['severity']); ?></td>
                <td><?php echo e($row['deviation']); ?></td>
                <td><?php echo e($row['description']); ?></td>
                <td><?php echo e($row['probable_cause']); ?></td>
                <td><?php echo e($row['immediate_action']); ?></td>
                <td><?php echo e($row['resolution']); ?></td>
                <td><?php echo e($row['preventive_recommendation']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\exports\energy_incident_report.blade.php ENDPATH**/ ?>