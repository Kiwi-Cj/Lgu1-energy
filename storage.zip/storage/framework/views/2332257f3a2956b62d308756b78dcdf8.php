<?php $__env->startSection('title', 'User Roles'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .roles-page {
        max-width: 1200px;
        margin: 0 auto;
    }
    .roles-header {
        margin-bottom: 24px;
    }
    .roles-title {
        font-size: 2.1rem;
        font-weight: 800;
        color: #1e3a8a;
        margin-bottom: 4px;
    }
    .roles-subtitle {
        font-size: 1rem;
        color: #64748b;
    }
    .roles-meta {
        margin-top: 10px;
        font-size: 0.95rem;
        color: #475569;
        font-weight: 600;
    }
    .roles-summary {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 16px;
        margin-bottom: 20px;
    }
    .roles-card {
        border-radius: 14px;
        padding: 20px 18px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 8px 18px rgba(15, 23, 42, 0.06);
        background: #ffffff;
    }
    .roles-card.roles-card-purple { background: #f5f3ff; border-color: #ddd6fe; }
    .roles-card.roles-card-blue { background: #eff6ff; border-color: #bfdbfe; }
    .roles-card.roles-card-green { background: #f0fdf4; border-color: #bbf7d0; }
    .roles-card-label {
        font-size: 0.9rem;
        font-weight: 700;
        color: #475569;
    }
    .roles-card-value {
        margin-top: 8px;
        font-size: 1.9rem;
        font-weight: 800;
        color: #0f172a;
    }
    .roles-actions {
        margin-bottom: 16px;
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }
    .roles-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 16px;
        border-radius: 10px;
        border: 1px solid #dbeafe;
        background: #eff6ff;
        color: #1d4ed8;
        font-weight: 700;
        text-decoration: none;
        cursor: default;
    }
    .roles-table-wrap {
        background: #ffffff;
        border-radius: 14px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 8px 20px rgba(15, 23, 42, 0.06);
        overflow-x: auto;
        overflow-y: hidden;
        -webkit-overflow-scrolling: touch;
    }
    .roles-table {
        width: 100%;
        border-collapse: collapse;
        text-align: center;
    }
    .roles-table thead tr {
        background: #eef2ff;
    }
    .roles-table th {
        color: #334155;
        font-size: 0.82rem;
        letter-spacing: 0.03em;
        text-transform: uppercase;
        padding: 12px 10px;
        border-bottom: 1px solid #dbeafe;
    }
    .roles-table td {
        padding: 14px 10px;
        border-top: 1px solid #edf2fb;
        color: #0f172a;
        vertical-align: middle;
    }
    .roles-table tbody tr:hover {
        background: #f8fbff;
    }
    .role-name-badge {
        display: inline-block;
        padding: 5px 12px;
        border-radius: 999px;
        color: #fff;
        font-size: 0.84rem;
        font-weight: 700;
    }
    .role-perm-badge {
        display: inline-block;
        padding: 5px 12px;
        border-radius: 999px;
        background: #dcfce7;
        color: #166534;
        font-size: 0.82rem;
        font-weight: 700;
    }
    .role-desc {
        text-align: left;
    }
    .role-desc small {
        display: block;
        margin-top: 6px;
        color: #64748b;
        font-weight: 600;
    }
    .role-action {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 34px;
        height: 34px;
        border-radius: 999px;
        color: #64748b;
        border: 1px solid #e2e8f0;
        text-decoration: none;
        cursor: default;
        margin: 0 3px;
    }
    .role-action.is-active {
        color: #2563eb;
        border-color: #bfdbfe;
        background: #eff6ff;
        cursor: pointer;
    }
    .role-action.is-active:hover {
        background: #dbeafe;
        border-color: #93c5fd;
    }
    .role-action.is-danger {
        color: #dc2626;
        border-color: #fecaca;
        background: #fef2f2;
    }
    .role-action.is-disabled {
        opacity: 0.45;
        cursor: not-allowed;
    }
    .roles-note {
        margin-top: 18px;
        color: #64748b;
        font-size: 0.9rem;
    }

    body.dark-mode .roles-title { color: #dbeafe; }
    body.dark-mode .roles-subtitle,
    body.dark-mode .roles-meta,
    body.dark-mode .roles-note { color: #94a3b8; }
    body.dark-mode .roles-card {
        background: #0f172a;
        border-color: #253043;
        box-shadow: 0 12px 26px rgba(2, 6, 23, 0.5);
    }
    body.dark-mode .roles-card.roles-card-purple { background: #1f1b3b; border-color: #4c1d95; }
    body.dark-mode .roles-card.roles-card-blue { background: #112038; border-color: #1d4ed8; }
    body.dark-mode .roles-card.roles-card-green { background: #0f2f2a; border-color: #14532d; }
    body.dark-mode .roles-card-label { color: #94a3b8; }
    body.dark-mode .roles-card-value { color: #f1f5f9; }
    body.dark-mode .roles-btn {
        background: #1e293b;
        border-color: #334155;
        color: #bfdbfe;
    }
    body.dark-mode .roles-table-wrap {
        background: #0f172a;
        border-color: #253043;
        box-shadow: 0 14px 26px rgba(2, 6, 23, 0.55);
    }
    body.dark-mode .roles-table thead tr { background: #172132; }
    body.dark-mode .roles-table th {
        color: #cbd5e1;
        border-bottom-color: #253043;
    }
    body.dark-mode .roles-table td {
        color: #e2e8f0;
        border-top-color: #1f2a3d;
    }
    body.dark-mode .roles-table tbody tr:hover { background: #132033; }
    body.dark-mode .role-perm-badge {
        background: #14532d;
        color: #dcfce7;
    }
    body.dark-mode .role-desc small { color: #94a3b8; }
    body.dark-mode .role-action {
        border-color: #334155;
        color: #94a3b8;
    }
    body.dark-mode .role-action.is-active {
        color: #bfdbfe;
        border-color: #334155;
        background: #1e293b;
    }
    body.dark-mode .role-action.is-active:hover {
        background: #334155;
    }
    body.dark-mode .role-action.is-danger {
        color: #fca5a5;
        border-color: #7f1d1d;
        background: #2b1014;
    }

    @media (max-width: 680px) {
        .roles-header {
            margin-bottom: 16px;
        }
        .roles-title {
            font-size: 1.45rem;
            line-height: 1.15;
        }
        .roles-subtitle {
            font-size: 0.9rem;
        }
        .roles-meta {
            margin-top: 8px;
            font-size: 0.84rem;
            line-height: 1.35;
        }
        .roles-summary {
            grid-template-columns: 1fr;
            gap: 10px;
            margin-bottom: 14px;
        }
        .roles-card {
            padding: 14px 14px;
            border-radius: 12px;
        }
        .roles-card-label {
            font-size: 0.82rem;
        }
        .roles-card-value {
            margin-top: 4px;
            font-size: 1.45rem;
        }
        .roles-actions {
            margin-bottom: 12px;
        }
        .roles-btn {
            width: 100%;
            justify-content: center;
            padding: 10px 12px;
            font-size: 0.88rem;
        }
        .roles-table-wrap {
            border-radius: 12px;
        }
        .roles-table {
            width: max-content;
            min-width: 860px;
        }
        .roles-table th,
        .roles-table td {
            padding: 10px 8px;
            font-size: 0.8rem;
            line-height: 1.2;
            white-space: nowrap;
        }
        .roles-table th {
            position: sticky;
            top: 0;
            z-index: 1;
        }
        .roles-table td:nth-child(1) {
            min-width: 42px;
        }
        .roles-table td:nth-child(2) {
            min-width: 120px;
        }
        .roles-table td:nth-child(3) {
            min-width: 300px;
            max-width: 300px;
            white-space: normal;
            word-break: break-word;
            line-height: 1.35;
        }
        .roles-table td:nth-child(4) {
            min-width: 180px;
        }
        .roles-table td:nth-child(5) {
            min-width: 120px;
            white-space: nowrap;
        }
        .role-name-badge {
            padding: 4px 10px;
            font-size: 0.76rem;
        }
        .role-perm-badge {
            padding: 4px 10px;
            font-size: 0.74rem;
            line-height: 1.2;
        }
        .role-desc small {
            margin-top: 4px;
            font-size: 0.75rem;
            line-height: 1.35;
        }
        .role-action {
            width: 30px;
            height: 30px;
            margin: 0 2px;
            font-size: 0.86rem;
        }
        .roles-note {
            margin-top: 12px;
            font-size: 0.82rem;
            line-height: 1.35;
        }
    }
</style>

<div class="roles-page">
    <div class="roles-header">
        <h1 class="roles-title">User Roles Management</h1>
        <div class="roles-subtitle">Define system roles and monitor assigned user distribution.</div>
        <div class="roles-meta">
            <span>Total Roles: <?php echo e($totalRoles ?? 0); ?></span> |
            <span>Assigned Users: <?php echo e($assignedUsers ?? 0); ?></span>
        </div>
    </div>

    <div class="roles-summary">
        <div class="roles-card roles-card-purple">
            <div class="roles-card-label">Total Roles</div>
            <div class="roles-card-value"><?php echo e($totalRoles ?? 0); ?></div>
        </div>
        <div class="roles-card roles-card-blue">
            <div class="roles-card-label">Assigned Users</div>
            <div class="roles-card-value"><?php echo e($assignedUsers ?? 0); ?></div>
        </div>
        <div class="roles-card roles-card-green">
            <div class="roles-card-label">Active Roles</div>
            <div class="roles-card-value"><?php echo e($activeRoles ?? 0); ?></div>
        </div>
    </div>

    <div class="roles-actions">
        <span class="roles-btn"><i class="fa fa-lock"></i> Role Templates Synced</span>
    </div>

    <div class="roles-table-wrap">
        <table class="roles-table">
            <thead>
                <tr>
                    <th style="width: 5%;">#</th>
                    <th style="width: 20%;">Role Name</th>
                    <th>Description</th>
                    <th style="width: 24%;">Permissions</th>
                    <th style="width: 15%;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $currentUserRole = (string) (auth()->user()?->role_key ?? str_replace(' ', '_', strtolower((string) (auth()->user()?->role ?? ''))));
                ?>
                <?php $__empty_1 = true; $__currentLoopData = ($roles ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $targetRoleKey = str_replace([' ', '-'], '_', strtolower((string) ($roleItem['key'] ?? '')));
                    $assignedCount = (int) ($roleItem['assigned_users'] ?? 0);
                    $canViewUsers = $currentUserRole === 'super_admin';
                    $canManageRole = $currentUserRole === 'super_admin'
                        && $targetRoleKey !== 'super_admin';
                    $canDeleteRole = $currentUserRole === 'super_admin'
                        && !in_array($targetRoleKey, ['super_admin', 'admin'], true)
                        && $assignedCount === 0;
                    $roleUsersUrl = route('users.index', ['role' => $targetRoleKey]);
                ?>
                <tr>
                    <td><?php echo e($roleItem['id']); ?></td>
                    <td>
                        <span class="role-name-badge" style="background:<?php echo e($roleItem['badge_color'] ?? '#6366f1'); ?>;">
                            <?php echo e($roleItem['name']); ?>

                        </span>
                    </td>
                    <td class="role-desc">
                        <div><?php echo e($roleItem['description']); ?></div>
                        <small>
                            Assigned: <?php echo e($roleItem['assigned_users'] ?? 0); ?> |
                            Active: <?php echo e($roleItem['active_users'] ?? 0); ?> |
                            Inactive: <?php echo e($roleItem['inactive_users'] ?? 0); ?>

                        </small>
                    </td>
                    <td>
                        <span class="role-perm-badge"><?php echo e($roleItem['permissions']); ?></span>
                    </td>
                    <td>
                        <a href="<?php echo e($canViewUsers ? $roleUsersUrl : 'javascript:void(0)'); ?>"
                           class="role-action <?php echo e($canViewUsers ? 'is-active' : 'is-disabled'); ?>"
                           title="<?php echo e($canViewUsers ? 'View users under this role' : 'View users is available for Super Admin only'); ?>">
                            <i class="fa fa-users"></i>
                        </a>
                        <a href="<?php echo e($canManageRole ? $roleUsersUrl : 'javascript:void(0)'); ?>"
                           class="role-action <?php echo e($canManageRole ? 'is-active' : 'is-disabled'); ?>"
                           title="<?php echo e($canManageRole ? 'Manage users for this role' : 'You do not have permission to manage this role'); ?>">
                            <i class="fa fa-pen"></i>
                        </a>
                        <a href="javascript:void(0)"
                           class="role-action is-danger <?php echo e($canDeleteRole ? 'is-active' : 'is-disabled'); ?>"
                           title="<?php echo e($canDeleteRole ? 'Delete role (available when no assigned users)' : 'Delete disabled: requires Super Admin and zero assigned users'); ?>">
                            <i class="fa fa-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No roles found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="roles-note">
        Note: Role records are derived from user role assignments. Editing role templates can be added as a next step.
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.qc-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\modules\users\roles.blade.php ENDPATH**/ ?>