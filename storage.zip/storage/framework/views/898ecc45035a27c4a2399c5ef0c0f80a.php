<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Energy System Portal</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('img/logocityhall.jpg')); ?>" /> 
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #f4f6fa;
        }
        .navbar {
            background: rgba(255,255,255,0.98);
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
        }
        .navbar-brand img {
            height: 38px;
            margin-right: 10px;
        }
        .hero-section {
            min-height: 90vh;
            background: url("<?php echo e(asset('img/energy illustration.jpg')); ?>") center center/cover no-repeat;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            position: relative;
            overflow: hidden;
            padding: 110px 0 80px;
        }
        .hero-section::before {
            content: "";
            position: absolute;
            inset: 0;
            background:
                linear-gradient(180deg, rgba(3, 12, 28, 0.28) 0%, rgba(3, 12, 28, 0.58) 45%, rgba(3, 12, 28, 0.68) 100%),
                radial-gradient(circle at center, rgba(8, 32, 64, 0.10) 0%, rgba(2, 8, 18, 0.30) 70%);
        }
        .hero-section .container {
            position: relative;
            z-index: 1;
            max-width: 980px;
            padding: 0 28px;
        }
        .hero-section h1 {
            font-size: clamp(2rem, 4.2vw, 3.5rem);
            font-weight: 700;
            line-height: 1.08;
            letter-spacing: 0.01em;
            margin-bottom: 14px;
            text-shadow: 0 4px 18px rgba(0, 0, 0, 0.7);
            animation: fadeInDown 1s;
            text-wrap: balance;
        }
        .hero-section p {
            font-size: clamp(1rem, 1.55vw, 1.35rem);
            line-height: 1.5;
            margin: 0 auto 30px;
            max-width: 980px;
            color: rgba(255, 255, 255, 0.97);
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.72);
            animation: fadeInUp 1.2s;
            text-wrap: pretty;
        }
        .hero-section .btn-primary {
            padding: 14px 38px;
            font-size: 1.1rem;
            border-radius: 30px;
            font-weight: 600;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.22);
            animation: fadeInUp 1.4s;
        }
        .hero-illustration {
            width: 100%;
            max-width: 480px;
            margin: 40px auto 0 auto;
            animation: fadeIn 2s;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .features-section {
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 2px 16px rgba(0,0,0,0.06);
            margin-top: -60px;
            padding: 48px 0 32px 0;
            position: relative;
            z-index: 2;
        }
        .feature-icon {
            font-size: 2.5rem;
            color: #3762c8;
            margin-bottom: 18px;
        }
        .feature-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 8px;
        }
        .testimonials-section {
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 2px 16px rgba(0,0,0,0.06);
            margin-top: 40px;
            padding: 40px 0 32px 0;
        }
        .testimonial {
            font-size: 1.08rem;
            color: #374151;
            margin-bottom: 18px;
        }
        .testimonial-author {
            font-weight: 600;
            color: #3762c8;
            font-size: 1rem;
        }
        .footer {
            background: #22223b;
            color: #e0e7ef;
            padding: 32px 0 18px 0;
            text-align: center;
            font-size: 1rem;
            margin-top: 48px;
        }
        .footer a { color: #a5b4fc; text-decoration: underline; }
        @media (max-width: 768px) {
            .hero-section {
                min-height: 72vh;
                padding: 90px 0 60px;
            }
            .hero-section .container {
                padding: 0 18px;
            }
            .hero-section p {
                font-size: 1rem;
                margin-bottom: 24px;
            }
            .hero-section .btn-primary {
                padding: 12px 26px;
                font-size: 1rem;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"/>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="#">
            <img src="<?php echo e(asset('img/logocityhall.jpg')); ?>" alt="Logo">
            <span class="fw-bold" style="font-size:1.25rem;">Energy System Portal</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('landing.features')); ?>">Features</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('landing.testimonials')); ?>">Testimonials</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('landing.contact')); ?>">Contact</a></li>
    
                   <a class="btn btn-primary ms-lg-3" href="<?php echo e(url('/login')); ?>">Login</a>
                
            </ul>
        </div>
    </div>
</nav>
<section class="hero-section">
    <div class="container">
        <h1>Energy System Portal</h1>
        <p>Monitor, analyze, and manage your energy records and facilities in one secure, user-friendly platform.</p>
        <a href="<?php echo e(route('landing.features')); ?>" class="btn btn-primary">Explore Features</a>
    </div>
</section>
<section class="features-section" id="features">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-3 text-center">
                <div class="feature-icon"><i class="fa-solid fa-bolt"></i></div>
                <div class="feature-title">Energy Monitoring</div>
                <div class="text-muted">Track and analyze energy usage across all facilities in real time.</div>
            </div>
            <div class="col-md-3 text-center">
                <div class="feature-icon"><i class="fa-solid fa-building"></i></div>
                <div class="feature-title">Facility Management</div>
                <div class="text-muted">Manage, maintain, and optimize all energy-related facilities efficiently.</div>
            </div>
            <div class="col-md-3 text-center">
                <div class="feature-icon"><i class="fa-solid fa-chart-line"></i></div>
                <div class="feature-title">Reports & Analytics</div>
                <div class="text-muted">Generate reports and gain insights for better decision-making.</div>
            </div>
            <div class="col-md-3 text-center">
                <div class="feature-icon"><i class="fa-solid fa-user-shield"></i></div>
                <div class="feature-title">Secure Access</div>
                <div class="text-muted">Role-based access for staff and administrators with strong security.</div>
            </div>
        </div>
    </div>
</section>
<section class="testimonials-section" id="testimonials">
    <div class="container">
        <h3 class="text-center mb-5">What Our Users Say</h3>
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="testimonial">"The Energy System Portal made our facility monitoring so much easier and more transparent. Highly recommended!"</div>
                <div class="testimonial-author">— Facility Manager, City Hall</div>
            </div>
            <div class="col-md-4">
                <div class="testimonial">"We love the analytics and reporting features. It helps us make data-driven decisions for energy savings."</div>
                <div class="testimonial-author"> Energy Officer, Public School</div>
            </div>
            <div class="col-md-4">
                <div class="testimonial">"Secure and easy to use. Our staff can now access records anytime, anywhere."</div>
                <div class="testimonial-author">— Admin, Local Government</div>
            </div>
        </div>
    </div>
</section>
<section class="container my-5" id="contact">
    <?php
        $contactUser = auth()->user();
        $prefillName = old('name', $contactUser?->full_name ?? $contactUser?->name ?? $contactUser?->username ?? '');
        $prefillEmail = old('email', $contactUser?->email ?? '');
    ?>
    <div class="row justify-content-center">
        <div class="col-lg-7 text-center">
            <h2 class="mb-3">Get in Touch</h2>
            <p class="mb-4 text-muted">Have a concern or inquiry? Send us a message and our team will respond as soon as possible to assist you.</p>
            <?php if(session('contact_success')): ?>
                <div class="alert alert-success text-start"><?php echo e(session('contact_success')); ?></div>
            <?php endif; ?>
            <?php if(session('contact_warning')): ?>
                <div class="alert alert-warning text-start"><?php echo e(session('contact_warning')); ?></div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger text-start">Please review the highlighted fields and try again.</div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('landing.contact.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-start d-block mb-1">Full Name</label>
                        <input type="text" name="name" value="<?php echo e($prefillName); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="e.g. Juan Dela Cruz" required>
                        <div class="form-text text-start">Use your personal full name, not office/facility name.</div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback text-start"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold text-start d-block mb-1">Email Address</label>
                        <input type="email" name="email" value="<?php echo e($prefillEmail); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="name@example.com" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback text-start"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold text-start d-block mb-1">Subject (Optional)</label>
                        <input type="text" name="subject" value="<?php echo e(old('subject')); ?>" class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="e.g. Police Station 12 concern">
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback text-start"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold text-start d-block mb-1">Message</label>
                        <textarea name="message" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="4" placeholder="Your Message" required><?php echo e(old('message')); ?></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback text-start"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12 d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Send Message</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<footer class="footer">
    <div class="container">
        <div class="mb-2">© 2026 Energy System Portal · All Rights Reserved</div>
        <div>For support, email <a href="mailto:support@energysystem.com">support@energysystem.com</a> or call <a href="tel:+15551234567">+1 (555) 123-4567</a></div>
        <div class="mt-2">
            <a href="#" class="me-3"><i class="fab fa-facebook fa-lg"></i></a>
            <a href="#" class="me-3"><i class="fab fa-twitter fa-lg"></i></a>
            <a href="#"><i class="fab fa-linkedin fa-lg"></i></a>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


<?php /**PATH C:\xampp\htdocs\Lgu1-energy\resources\views\welcome.blade.php ENDPATH**/ ?>