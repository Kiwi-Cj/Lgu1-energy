<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    protected $fillable = [
        'user_id', 'title', 'message', 'type', 'target_url', 'read_at'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
