@extends('layouts.qc-admin')
@section('title', 'Users')




@section('content')
<div class="report card users-shell" style="padding:32px 24px 32px 24px; background:#f8fafc; border-radius:18px; box-shadow:0 8px 32px rgba(37,99,235,0.09); margin-bottom:32px;">

@php
	$user = auth()->user();
	$role = \App\Support\RoleAccess::normalize($user?->role ?? '');
	$isSuperAdmin = $role === 'super_admin';
	$canAccessUsersPage = in_array($role, ['super_admin', 'admin'], true);
@endphp


@if(!$canAccessUsersPage)
	<div style="max-width:600px;margin:60px auto 0 auto;padding:32px 24px;background:#fff0f3;border-radius:14px;box-shadow:0 2px 8px rgba(225,29,72,0.08);text-align:center;">
		<h2 style="color:#e11d48;font-size:2rem;font-weight:800;margin-bottom:12px;">Restricted Access</h2>
		<div style="font-size:1.2rem;color:#b91c1c;margin-bottom:18px;">This page is for <b>Super Admin</b> and <b>Admin</b> only.</div>
		<a href="/modules/dashboard/index" style="display:inline-block;margin-top:18px;padding:10px 24px;background:#3762c8;color:#fff;border-radius:8px;text-decoration:none;font-weight:600;">Go to Dashboard</a>
	</div>
@else
	<style>
		.users-shell {
			border: 1px solid #dbe6f5;
			background: linear-gradient(180deg, #f8fbff 0%, #f1f6fd 100%) !important;
		}
		.users-title {
			color: #1e1b4b !important;
			text-shadow: 0 1px 0 rgba(255, 255, 255, 0.85);
		}
		.users-stat-grid {
			display: grid !important;
			grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
			gap: 16px !important;
			margin-bottom: 28px !important;
		}
		.users-stat-card {
			max-width: none !important;
			margin: 0 !important;
			border: 1px solid rgba(148, 163, 184, 0.24);
			transition: transform .18s ease, box-shadow .18s ease;
		}
		.users-stat-card:hover {
			transform: translateY(-3px);
			box-shadow: 0 14px 28px rgba(37, 99, 235, 0.13) !important;
		}
		.users-actions {
			margin-bottom: 18px !important;
			padding: 4px 0;
		}
		.users-btn-primary,
		.users-btn-secondary {
			border: 1px solid transparent !important;
			transition: transform .15s ease, box-shadow .2s ease, background .2s ease, color .2s ease;
		}
		.users-btn-primary:hover,
		.users-btn-secondary:hover {
			transform: translateY(-1px);
			box-shadow: 0 8px 18px rgba(37, 99, 235, 0.18) !important;
		}
		.users-btn-secondary {
			background: #eef2ff !important;
			border-color: #c7d2fe !important;
		}
		.users-table-wrap {
			border: 1px solid #dbe6f5;
			overflow-x: auto;
			-webkit-overflow-scrolling: touch;
		}
		.users-table {
			min-width: 860px;
			border-collapse: separate;
			border-spacing: 0;
		}
		.users-table thead tr {
			background: linear-gradient(135deg, #edf3ff 0%, #e5ecff 100%) !important;
		}
		.users-table th {
			color: #334155;
			font-size: .9rem;
			text-transform: uppercase;
			letter-spacing: .03em;
			border-bottom: 1px solid #dbe6f5;
		}
		.users-table td {
			color: #0f172a;
			border-top: 1px solid #edf2fb;
			vertical-align: middle;
		}
		.users-table th,
		.users-table td {
			padding: 12px 10px;
		}
		.users-actions-cell {
			white-space: nowrap;
		}
		.users-table tbody tr:hover {
			background: #f8fbff;
		}
		.users-role-overview {
			padding: 16px 18px;
			background: #f8fbff;
			border: 1px solid #dde7f4;
			border-radius: 12px;
		}
		.users-role-overview ul li {
			margin-bottom: 6px;
			color: #334155;
		}
		.action-btn-view:hover .action-label-view,
		.action-btn-edit:hover .action-label-edit,
		.action-btn-delete:hover .action-label-delete {
			visibility: visible !important;
			opacity: 1 !important;
		}

		/* Simple modal (no bootstrap needed) */
		.modal-backdrop, .modal-overlay, .modal {
			position: fixed;
			inset: 0;
			background: rgba(15,23,42,0.6) !important;
			display: none;
			z-index: 9998;
			backdrop-filter: blur(4px) !important;
		}
		.modal-sheet, .modal-content {
			position: fixed;
			inset: 0;
			display: none;
			z-index: 9999;
			padding: 18px;
			overflow: auto;
		}
		.modal-card {
			max-width: 860px;
			margin: 40px auto;
			background: #fff;
			border-radius: 14px;
		}
		body.dark-mode .users-shell {
			background: linear-gradient(170deg, #0f172a 0%, #111827 100%) !important;
			border-color: #1f2c44 !important;
			box-shadow: 0 14px 30px rgba(2, 6, 23, 0.42) !important;
		}
		body.dark-mode .users-title {
			color: #e2e8f0 !important;
			text-shadow: none;
		}
		body.dark-mode .users-stat-card {
			background: #0f172a !important;
			color: #e2e8f0 !important;
			border-color: #253043 !important;
			box-shadow: 0 10px 24px rgba(2, 6, 23, 0.45) !important;
		}
		body.dark-mode .users-stat-card > div {
			color: #cbd5e1 !important;
		}
		body.dark-mode .users-stat-card > div:first-child span {
			color: inherit !important;
		}
		body.dark-mode .users-stat-card.users-stat-total {
			background: linear-gradient(145deg, #1e293b 0%, #172554 100%) !important;
		}
		body.dark-mode .users-stat-card.users-stat-active {
			background: linear-gradient(145deg, #0f2f2a 0%, #14532d 100%) !important;
		}
		body.dark-mode .users-stat-card.users-stat-roles {
			background: linear-gradient(145deg, #1f2540 0%, #312e81 100%) !important;
		}
		body.dark-mode .users-stat-card.users-stat-roles > div:nth-child(2) > span {
			background: #2e275a !important;
			color: #ede9fe !important;
			box-shadow: 0 0 0 1px rgba(196, 181, 253, 0.36) !important;
		}
		body.dark-mode .users-stat-card.users-stat-roles > div:nth-child(2) > span > span:last-child {
			background: #a78bfa !important;
			color: #1e1b4b !important;
		}
		body.dark-mode .users-stat-card.users-stat-inactive {
			background: linear-gradient(145deg, #312027 0%, #7f1d1d 100%) !important;
		}
		body.dark-mode .users-btn-secondary {
			background: #1e293b !important;
			color: #c4b5fd !important;
			border-color: #334155 !important;
		}
		body.dark-mode .users-btn-secondary:hover {
			background: #334155 !important;
			color: #e2e8f0 !important;
		}
		body.dark-mode .users-table-wrap,
		body.dark-mode .users-table {
			background: #0f172a !important;
			border-color: #223047 !important;
		}
		body.dark-mode .users-table thead tr {
			background: #172132 !important;
		}
		body.dark-mode .users-table th {
			color: #cbd5e1 !important;
			border-color: #253043 !important;
		}
		body.dark-mode .users-table td {
			color: #e2e8f0 !important;
			border-color: #1f2a3d !important;
		}
		body.dark-mode .users-table tbody tr:hover {
			background: #131f31 !important;
		}
		body.dark-mode .users-role-overview {
			background: #111a2a !important;
			border-color: #253043 !important;
		}
		body.dark-mode .users-role-overview ul li {
			color: #cbd5e1 !important;
		}
		body.dark-mode .user-edit-modal-pro,
		body.dark-mode .user-view-modal-pro,
		body.dark-mode .modal-card {
			background: #0f172a !important;
			border: 1px solid #253043 !important;
			box-shadow: 0 20px 40px rgba(2, 6, 23, 0.6) !important;
		}
		body.dark-mode .uv-modal-title,
		body.dark-mode .uv-value {
			color: #f1f5f9 !important;
		}
		body.dark-mode .uv-modal-subtitle,
		body.dark-mode .uv-label,
		body.dark-mode .uv-password-hint {
			color: #94a3b8 !important;
		}
		body.dark-mode .uv-modal-row {
			border-bottom-color: #1f2a3d !important;
		}
		body.dark-mode .uv-form-field label {
			color: #dbeafe !important;
		}
		body.dark-mode .uv-form-field input,
		body.dark-mode .uv-form-field select,
		body.dark-mode #facilitySearch {
			background: #111827 !important;
			border-color: #334155 !important;
			color: #e2e8f0 !important;
		}
		body.dark-mode .facility-checkbox-scroll,
		body.dark-mode .facility-checkbox-item {
			background: #111827 !important;
			border-color: #334155 !important;
			color: #e2e8f0 !important;
		}
		body.dark-mode .facility-checkbox-item:hover {
			background: #1f2937 !important;
		}
		body.dark-mode .facility-badge {
			background: #1e293b !important;
			color: #dbeafe !important;
			box-shadow: 0 0 0 1px #334155 !important;
		}
		@media (max-width: 680px) {
			.users-shell {
				padding: 20px 14px !important;
			}
			.users-title {
				font-size: 1.5rem !important;
				line-height: 1.15;
				margin-bottom: 14px !important;
			}
			.users-stat-grid {
				grid-template-columns: 1fr !important;
				gap: 12px !important;
				margin-bottom: 18px !important;
			}
			.users-stat-card {
				min-width: 0 !important;
				padding: 16px 14px !important;
				border-radius: 14px !important;
			}
			.users-stat-card > div:first-child {
				font-size: 0.95rem !important;
			}
			.users-stat-total > div:last-child,
			.users-stat-active > div:last-child,
			.users-stat-inactive > div:last-child {
				font-size: 2rem !important;
			}
			.users-actions {
				gap: 10px !important;
				flex-direction: column;
				align-items: stretch !important;
				margin-bottom: 16px !important;
			}
			.users-btn-primary,
			.users-btn-secondary {
				width: 100%;
				justify-content: center;
				padding: 11px 14px !important;
				font-size: 0.96rem !important;
			}
			.users-table-wrap {
				padding: 10px !important;
				overflow-x: auto !important;
				overflow-y: hidden !important;
				-webkit-overflow-scrolling: touch;
			}
			.users-table {
				min-width: 720px !important;
				width: max-content !important;
			}
			.users-table th,
			.users-table td {
				padding: 10px 8px !important;
				font-size: 0.82rem !important;
				line-height: 1.2;
				white-space: nowrap;
			}
			.users-table th {
				position: sticky;
				top: 0;
				z-index: 1;
			}
			.users-table td:nth-child(3) {
				max-width: 180px;
				white-space: normal;
				word-break: break-word;
			}
			.users-table td.users-actions-cell {
				gap: 8px !important;
			}
			.users-table td.users-actions-cell .action-label-view,
			.users-table td.users-actions-cell .action-label-edit,
			.users-table td.users-actions-cell .action-label-delete {
				display: none !important;
			}
			.users-table td.users-actions-cell a {
				font-size: 1rem !important;
			}
			.users-role-overview {
				margin-top: 1rem !important;
				padding: 14px !important;
			}
			.facility-checkbox-grid {
				grid-template-columns: 1fr !important;
				gap: 8px !important;
			}
			.uv-form-grid-2 {
				grid-template-columns: 1fr !important;
			}
			.modal-sheet,
			.modal-content {
				padding: 10px !important;
			}
			.modal-card,
			.user-edit-modal-pro,
			.user-view-modal-pro {
				width: 100% !important;
				margin: 8px auto !important;
				border-radius: 14px !important;
			}
			.modal-close-pro {
				top: 10px !important;
				right: 10px !important;
			}
			.uv-modal-header {
				padding: 22px 16px 0 16px !important;
			}
			.uv-modal-title {
				font-size: 1.2rem !important;
				padding-right: 28px;
			}
			.uv-modal-subtitle {
				font-size: 0.92rem !important;
				margin-bottom: 12px !important;
			}
			.uv-modal-form {
				padding: 14px 16px 0 16px !important;
			}
			.uv-modal-content {
				padding: 0 16px !important;
				gap: 8px !important;
			}
			.uv-modal-row {
				flex-direction: column;
				gap: 4px;
				padding: 10px 0;
			}
			.uv-label {
				min-width: 0;
			}
			.uv-value {
				text-align: left;
				width: 100%;
			}
			.uv-modal-actions {
				padding: 0 16px !important;
				flex-direction: column-reverse;
				align-items: stretch;
				gap: 10px !important;
			}
			.uv-btn-cancel,
			.uv-btn-submit,
			.uv-btn-close {
				width: 100%;
			}
		}
	</style>
	<h1 class="users-title" style="font-size:2.1rem;font-weight:800;color:#312e81;margin-bottom:10px;letter-spacing:-1px;">Users and Roles</h1>
	<div class="users-stat-grid" style="display:flex;flex-wrap:wrap;gap:24px 2%;margin-bottom:32px;justify-content:space-between;">
		<div class="users-stat-card users-stat-total" style="flex:1 1 220px;min-width:220px;max-width:24%;background:#fff;padding:24px 18px;border-radius:18px;box-shadow:0 4px 16px rgba(55,98,200,0.10);margin-bottom:0;display:flex;flex-direction:column;align-items:flex-start;">
			<div style="font-size:1.1rem;font-weight:600;color:#4f46e5;display:flex;align-items:center;gap:8px;"><span style='font-size:1.3rem;'>👥</span> Total Users</div>
			<div style="font-size:2.5rem;font-weight:800;margin:12px 0 0 0;line-height:1;">{{ $totalUsers ?? '-' }}</div>
		</div>
		<div class="users-stat-card users-stat-active" style="flex:1 1 220px;min-width:220px;max-width:24%;background:#ecfdf5;padding:24px 18px;border-radius:18px;box-shadow:0 4px 16px rgba(34,197,94,0.10);margin-bottom:0;display:flex;flex-direction:column;align-items:flex-start;">
			<div style="font-size:1.1rem;font-weight:600;color:#16a34a;display:flex;align-items:center;gap:8px;"><span style='font-size:1.3rem;'>🟢</span> Active Users</div>
			<div style="font-size:2.5rem;font-weight:800;margin:12px 0 0 0;line-height:1;">{{ $activeUsers ?? '-' }}</div>
		</div>
		<div class="users-stat-card users-stat-roles" style="flex:1 1 220px;min-width:220px;max-width:24%;background:#f5f3ff;padding:24px 18px;border-radius:18px;box-shadow:0 4px 16px rgba(139,92,246,0.10);margin-bottom:0;display:flex;flex-direction:column;align-items:flex-start;">
			<div style="font-size:1.1rem;font-weight:600;color:#8b5cf6;display:flex;align-items:center;gap:8px;"><span style='font-size:1.3rem;'>🔐</span> Roles</div>
			<div style="display:flex;flex-wrap:wrap;gap:8px 10px;margin-top:14px;">
				@php
					$roleCounts = collect($users ?? [])->groupBy('role')->map->count();
					$rolesCollection = $roleCounts->mapWithKeys(function ($count, $role) {
						$label = str_replace('_', ' ', trim($role));
						$label = ucwords($label);
						return [$label => $count];
					})->sortKeys();
					if ($rolesCollection->isEmpty()) {
						$rolesCollection = collect([
							'Admin'          => 0,
							'Energy Officer' => 0,
							'Staff'          => 0,
						]);
					}
				@endphp
				@foreach($rolesCollection as $roleLabel => $count)
					<span style="background:#ede9fe;padding:4px 14px;border-radius:999px;font-size:1rem;font-weight:600;color:#7c3aed;box-shadow:0 0 0 1px rgba(124,58,237,0.18);display:inline-flex;align-items:center;gap:6px;">
						<span>{{ $roleLabel }}</span>
						<span style="min-width:22px;height:22px;border-radius:999px;background:#7c3aed;color:#fdfbff;font-size:0.85rem;display:inline-flex;align-items:center;justify-content:center;">{{ $count }}</span>
					</span>
				@endforeach
			</div>
		</div>
		<div class="users-stat-card users-stat-inactive" style="flex:1 1 220px;min-width:220px;max-width:24%;background:#fef2f2;padding:24px 18px;border-radius:18px;box-shadow:0 4px 16px rgba(225,29,72,0.10);margin-bottom:0;display:flex;flex-direction:column;align-items:flex-start;">
			<div style="font-size:1.1rem;font-weight:600;color:#e11d48;display:flex;align-items:center;gap:8px;"><span style='font-size:1.3rem;'>🚫</span> Inactive Users</div>
			<div style="font-size:2.5rem;font-weight:800;margin:12px 0 0 0;line-height:1;">{{ $inactiveUsers ?? '-' }}</div>
		</div>
	</div>
	<!-- 4️⃣ ACTION BUTTONS -->
	<div class="users-actions" style="margin-bottom:24px;display:flex;gap:18px;flex-wrap:wrap;align-items:center;">
		<button type="button" onclick="openUserModalCreate()" class="users-btn-primary" style="display:flex;align-items:center;gap:8px;padding:10px 22px;font-size:1.08rem;font-weight:600;background:#4f46e5;color:#fff;border:none;border-radius:10px;box-shadow:0 2px 8px rgba(79,70,229,0.10);transition:background 0.18s,box-shadow 0.18s;cursor:pointer;outline:none;">
			<span style="font-size:1.25rem;display:flex;align-items:center;">➕</span> Add New User
		</button>
		<a href="{{ route('users.roles') }}" class="users-btn-secondary"
		   style="display:flex;align-items:center;gap:8px;padding:10px 22px;font-size:1.08rem;font-weight:600;background:#ede9fe;color:#7c3aed;border:none;border-radius:10px;box-shadow:0 2px 8px rgba(124,58,237,0.10);text-decoration:none;transition:background 0.18s,box-shadow 0.18s,color 0.18s;cursor:pointer;outline:none;"
		   onmouseover="this.style.background='#c7d2fe';this.style.color='#4f46e5'"
		   onmouseout="this.style.background='#ede9fe';this.style.color='#7c3aed'">
			<span style="font-size:1.25rem;display:flex;align-items:center;">🧩</span> Manage Roles
		</a>
	</div>
	<!-- 3️⃣ USERS TABLE -->
	<div class="users-table-wrap" style="background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(55,98,200,0.07);padding:18px;">
		<table class="table users-table" style="width:100%;background:#fff;border-radius:10px;overflow:hidden;text-align:center;">
			<thead style="background:#e9effc;">
				<tr>
					<th>User ID</th>
					<th>Full Name</th>
					<th>Email / Username</th>
					<th>Role</th>
					<th>Assigned Facilities<br><span style="font-weight:400;font-size:0.95em;color:#888;">(#)</span></th>
					<th>Status</th>
					<th style="text-align:center;vertical-align:middle;">Actions</th>
				</tr>
			</thead>
			<tbody>
				@forelse($users as $user)
				<tr>
					<td data-label="User ID">{{ $user->id }}</td>
					<td data-label="Full Name">{{ $user->full_name ?? $user->name ?? '-' }}</td>
					<td data-label="Email / Username">{{ $user->email }}</td>
					<td data-label="Role">{{ $user->role }}</td>
					<td data-label="Assigned Facilities (#)">
						@php $facilityCount = $user->facilities ? $user->facilities->count() : 0; @endphp
						<span style="font-weight:700;color:#6366f1;font-size:1.1em;">{{ $facilityCount }}</span>
					</td>
					<td data-label="Status">
						@if(strtolower($user->status ?? '') == 'active')
							<span style="display:inline-block;padding:4px 12px;border-radius:999px;background:#dcfce7;color:#16a34a;font-weight:600;font-size:0.85rem;">
								{{ ucfirst($user->status) }}
							</span>
						@else
							<span style="display:inline-block;padding:4px 12px;border-radius:999px;background:#fee2e2;color:#b91c1c;font-weight:600;font-size:0.85rem;">
								{{ $user->status ?? 'Inactive' }}
							</span>
						@endif
					</td>
					<td data-label="Actions" class="users-actions-cell" style="display:flex;gap:10px;align-items:center;justify-content:center;vertical-align:middle;">
						<a href="javascript:void(0)"
						   onclick="openUserModalView(this)"
						   data-user="{{ json_encode([
								'id' => $user->id,
								'full_name' => $user->full_name ?? $user->name ?? '',
								'email' => $user->email ?? '',
								'username' => $user->username ?? '',
								'role' => $user->role ?? '',
								'status' => $user->status ?? '',
								   'facilities' => $user->facilities ? $user->facilities->pluck('name')->toArray() : [],
								'department' => $user->department ?? '',
								'contact_number' => $user->contact_number ?? '',
						   ], JSON_HEX_APOS | JSON_HEX_QUOT) }}"
						   class="action-btn-view"
						   style="position:relative; color:#6366f1; font-size:1.2rem; display:inline-flex; align-items:center; text-decoration:none;">
							<i class="fa fa-eye"></i>
							<span class="action-label-view" style="visibility:hidden;opacity:0;position:absolute;right:36px;left:auto;top:50%;transform:translateY(-50%);background:#222;color:#fff;padding:4px 14px;min-width:54px;border-radius:6px;font-size:0.98rem;white-space:nowrap;transition:opacity 0.18s;pointer-events:none;z-index:9999;box-shadow:0 2px 8px rgba(0,0,0,0.12);">View</span>
						</a>
						<a href="javascript:void(0)"
						   onclick="openUserModalEdit(this)"
						   data-user-id="{{ $user->id }}"
						   data-user="{{ json_encode([
								'id' => $user->id,
								'full_name' => $user->full_name ?? $user->name ?? '',
								'email' => $user->email ?? '',
								'username' => $user->username ?? '',
								'role' => strtolower($user->role ?? ''),
								'status' => strtolower($user->status ?? 'active'),
								   'facility_ids' => $user->facilities ? $user->facilities->pluck('id')->toArray() : [],
								'department' => $user->department ?? '',
								'contact_number' => $user->contact_number ?? '',
						   ], JSON_HEX_APOS | JSON_HEX_QUOT) }}"
						   class="action-btn-edit"
						   style="position:relative; color:#6366f1; font-size:1.2rem; display:inline-flex; align-items:center; text-decoration:none; cursor:pointer;">
							<i class="fa fa-pen"></i>
							<span class="action-label-edit" style="visibility:hidden;opacity:0;position:absolute;right:36px;left:auto;top:50%;transform:translateY(-50%);background:#222;color:#fff;padding:4px 14px;min-width:54px;border-radius:6px;font-size:0.98rem;white-space:nowrap;transition:opacity 0.18s;pointer-events:none;z-index:9999;box-shadow:0 2px 8px rgba(0,0,0,0.12);">Edit</span>
						</a>
						<a href="{{ url('modules/users/disable/'.$user->id) }}" class="action-btn-delete" style="position:relative; color:#e11d48; font-size:1.2rem; display:inline-flex; align-items:center; text-decoration:none;">
							<i class="fa fa-trash"></i>
							<span class="action-label-delete" style="visibility:hidden;opacity:0;position:absolute;right:36px;left:auto;top:50%;transform:translateY(-50%);background:#222;color:#fff;padding:4px 14px;min-width:54px;border-radius:6px;font-size:0.98rem;white-space:nowrap;transition:opacity 0.18s;pointer-events:none;z-index:9999;box-shadow:0 2px 8px rgba(0,0,0,0.12);">Disable</span>
						</a>
					</td>
				</tr>
				@empty
				<tr><td colspan="7">No users found.</td></tr>
				@endforelse
			</tbody>
		</table>
	</div>
	<!-- 5️⃣ ROLES OVERVIEW (Optional) -->
	<div class="users-role-overview" style="margin-top:2.5rem;">
		<h3 style="font-size:1.2rem;font-weight:700;color:#3762c8;margin-bottom:10px;">Roles Overview</h3>
		<ul style="list-style:none;padding:0;">
			<li><b>Admin:</b> Full system access</li>
			<li><b>Energy Officer:</b> Reports & analytics</li>
			<li><b>Staff:</b> Data entry only</li>
		</ul>
	</div>
	<!-- USER MODAL -->
	   <div class="modal-backdrop" id="userModalBackdrop" onclick="closeUserModal()"></div>
	   <div class="modal-sheet" id="userModalSheet" aria-hidden="true">
		   <div class="modal-card user-edit-modal-pro" role="dialog" aria-modal="true">
			   <button type="button" class="modal-close-pro" onclick="closeUserModal()" aria-label="Close">&times;</button>
			   <div class="uv-modal-header">
				   <h2 class="uv-modal-title" id="userModalTitle">Create User</h2>
				   <div class="uv-modal-subtitle" id="userModalSubtitle">Add a new system user and optionally assign a facility (Staff only).</div>
			   </div>
			   <form id="userModalForm" method="POST" action="{{ route('users.store') }}" class="uv-modal-form">
				   @csrf
				   <input type="hidden" id="userModalMethod" name="_method" value="">
				   <div class="uv-form-grid">
					   <div class="uv-form-field">
						   <label for="um_full_name">Full Name *</label>
						   <input id="um_full_name" name="full_name" type="text" required>
					   </div>
					   <div class="uv-form-field">
						   <label for="um_email">Email *</label>
						   <input id="um_email" name="email" type="email" required>
					   </div>
					   <div class="uv-form-field">
						   <label for="um_username">Username</label>
						   <input id="um_username" name="username" type="text">
					   </div>
					   <div class="uv-form-field">
						   <label for="um_role">Role *</label>
						   <select id="um_role" name="role" required onchange="toggleUserModalFacility()">
							   <option value="">Select Role</option>
							   @if($isSuperAdmin)
								 <option value="super admin">Super Admin</option>
								 <option value="admin">Admin</option>
							   @endif
							   <option value="staff">Staff</option>
							   <option value="energy_officer">Energy Officer</option>
							   <option value="engineer">Engineer</option>
						   </select>
					   </div>
					   <div class="uv-form-field" id="um_facility_wrap" style="display:none;">
						   <label>Assigned Facility <span style='font-weight:400;color:#888;'>(Staff only, optional, multiple allowed)</span></label>
						   <input type="text" id="facilitySearch" placeholder="Search facility..." style="margin-bottom:8px;width:100%;padding:7px 10px;border-radius:6px;border:1px solid #e0e7ef;">
						   <div class="facility-checkbox-grid facility-checkbox-scroll" id="facilityCheckboxList">
							   @foreach(($facilities ?? []) as $facility)
								   <label class="facility-checkbox-item">
									   <input type="checkbox" name="facility_id[]" value="{{ $facility->id }}">
									   <span>{{ $facility->name }}</span>
								   </label>
							   @endforeach
						   </div>
					   </div>
					   <div class="uv-form-field">
						   <label for="um_status">Status *</label>
						   <select id="um_status" name="status" required>
							   <option value="active">Active</option>
							   <option value="inactive">Inactive</option>
						   </select>
					   </div>
					   <div class="uv-form-field">
						   <label for="um_department">Department</label>
						   <input id="um_department" name="department" type="text">
					   </div>
					   <div class="uv-form-field">
						   <label for="um_contact_number">Contact Number</label>
						   <input id="um_contact_number" name="contact_number" type="text">
					   </div>
				   </div>
				   <div id="um_password_block" class="uv-password-block">
					   <div class="uv-password-tools" id="um_password_tools">
						   <label class="uv-password-autogen">
							   <input type="checkbox" id="um_password_autogen_toggle">
							   <span>Auto-generate strong password</span>
						   </label>
						   <button type="button" class="uv-password-generate-btn" id="um_password_generate_btn" onclick="generateUserModalPassword()" style="display:none;">Generate</button>
					   </div>
					   <div class="uv-form-grid uv-form-grid-2">
						   <div class="uv-form-field">
							   <label for="um_password" id="um_password_label">Password *</label>
							   <div class="uv-password-input-wrap">
								   <input id="um_password" name="password" type="password" autocomplete="new-password">
								   <button type="button" class="uv-password-toggle-btn" id="um_password_toggle_btn" onclick="toggleUserModalPasswordVisibility('um_password', this)">Show</button>
							   </div>
						   </div>
						   <div class="uv-form-field">
							   <label for="um_password_confirmation" id="um_password_confirmation_label">Confirm Password *</label>
							   <div class="uv-password-input-wrap">
								   <input id="um_password_confirmation" name="password_confirmation" type="password" autocomplete="new-password">
								   <button type="button" class="uv-password-toggle-btn" id="um_password_confirmation_toggle_btn" onclick="toggleUserModalPasswordVisibility('um_password_confirmation', this)">Show</button>
							   </div>
						   </div>
					   </div>
					   <div class="uv-password-hint" id="um_password_hint">Password is required when creating a new user.</div>
				   </div>
				   <div class="uv-modal-actions">
					   <button type="button" class="uv-btn-cancel" onclick="closeUserModal()">Cancel</button>
					   <button type="submit" id="userModalSubmitBtn" class="uv-btn-submit">Create User</button>
				   </div>
			   </form>
		   </div>
	   </div>

	   <style>
	   .facility-checkbox-grid {
		   display: grid;
		   grid-template-columns: 1fr 1fr;
		   gap: 8px 18px;
		   margin: 8px 0 0 0;
	   }
	   .facility-checkbox-item {
		   display: flex;
		   align-items: center;
		   gap: 8px;
		   font-size: 1rem;
		   color: #312e81;
		   font-weight: 500;
		   background: #f8fafc;
		   border-radius: 6px;
		   padding: 6px 10px;
		   transition: background 0.18s;
		   cursor: pointer;
	   }
	   .facility-checkbox-item input[type="checkbox"] {
		   accent-color: #6366f1;
		   width: 18px;
		   height: 18px;
		   margin-right: 4px;
	   }
	   .facility-checkbox-item:hover {
		   background: #e0e7ef;
	   }
	   .facility-checkbox-scroll {
		   max-height: 220px;
		   overflow-y: auto;
		   border: 1px solid #e0e7ef;
		   background: #f8fafc;
		   padding-right: 4px;
	   }
	   .user-edit-modal-pro {
		   max-width: 720px;
		   width: 96vw;
		   margin: 40px auto;
		   background: #fff;
		   border-radius: 18px;
		   box-shadow: 0 8px 32px rgba(49,46,129,0.13), 0 2px 8px rgba(30,41,59,0.07);
		   padding: 0 0 18px 0;
		   position: relative;
		   animation: pop 0.22s cubic-bezier(.4,2,.6,1);
	   }
	   .modal-close-pro {
		   position: absolute;
		   top: 18px;
		   right: 22px;
		   background: none;
		   border: none;
		   font-size: 2.1rem;
		   color: #64748b;
		   cursor: pointer;
		   border-radius: 50%;
		   width: 38px;
		   height: 38px;
		   display: flex;
		   align-items: center;
		   justify-content: center;
		   transition: background 0.18s, color 0.18s;
	   }
	   .modal-close-pro:hover {
		   background: #e0e7ef;
		   color: #e11d48;
	   }
	   .uv-modal-header {
		   padding: 38px 38px 0 38px;
		   text-align: center;
	   }
	   .uv-modal-title {
		   font-size: 1.45rem;
		   font-weight: 800;
		   color: #312e81;
		   margin-bottom: 2px;
	   }
	   .uv-modal-subtitle {
		   font-size: 1.08rem;
		   color: #6366f1;
		   font-weight: 500;
		   margin-bottom: 18px;
	   }
	   .uv-modal-form {
		   padding: 18px 38px 0 38px;
	   }
	   .uv-form-grid {
		   display: grid;
		   grid-template-columns: 1fr;
		   gap: 16px;
	   }
	   @media (min-width: 600px) {
		   .uv-form-grid {
			   grid-template-columns: 1fr 1fr;
			   gap: 18px 24px;
		   }
		   .uv-form-field {
			   min-width: 0;
		   }
	   }
	   .uv-form-grid-2 {
		   grid-template-columns: 1fr 1fr;
	   }
	   .uv-form-field {
		   display: flex;
		   flex-direction: column;
		   gap: 4px;
	   }
	   .uv-form-field label {
		   font-weight: 700;
		   color: #312e81;
		   font-size: 1rem;
	   }
	   .uv-form-field input,
	   .uv-form-field select {
		   width: 100%;
		   padding: 10px 12px;
		   border-radius: 8px;
		   border: 1px solid #e0e7ef;
		   font-size: 1rem;
		   background: #f8fafc;
		   transition: border 0.18s, background 0.18s;
	   }
	   .uv-form-field input:focus,
	   .uv-form-field select:focus {
		   border-color: #6366f1;
		   background: #f0f6ff;
		   outline: none;
	   }
	   .uv-password-block {
		   margin-top: 14px;
	   }
	   .uv-password-tools {
		   display: flex;
		   align-items: center;
		   justify-content: space-between;
		   gap: 10px;
		   margin-bottom: 10px;
		   flex-wrap: wrap;
	   }
	   .uv-password-autogen {
		   display: inline-flex;
		   align-items: center;
		   gap: 8px;
		   font-size: 0.95rem;
		   color: #334155;
		   font-weight: 600;
		   cursor: pointer;
	   }
	   .uv-password-autogen input[type="checkbox"] {
		   accent-color: #4f46e5;
		   width: 16px;
		   height: 16px;
	   }
	   .uv-password-generate-btn {
		   border: 1px solid #c7d2fe;
		   background: #eef2ff;
		   color: #4338ca;
		   border-radius: 8px;
		   padding: 7px 12px;
		   font-weight: 700;
		   cursor: pointer;
	   }
	   .uv-password-input-wrap {
		   position: relative;
		   display: flex;
		   align-items: center;
	   }
	   .uv-password-input-wrap input {
		   padding-right: 64px !important;
	   }
	   .uv-password-toggle-btn {
		   position: absolute;
		   right: 8px;
		   top: 50%;
		   transform: translateY(-50%);
		   border: 1px solid #dbeafe;
		   background: #eff6ff;
		   color: #1d4ed8;
		   border-radius: 7px;
		   padding: 4px 8px;
		   font-size: 0.78rem;
		   font-weight: 700;
		   cursor: pointer;
	   }
	   .uv-password-hint {
		   margin-top: 6px;
		   color: #666;
		   font-size: 0.95rem;
	   }
	   .uv-modal-actions {
		   display: flex;
		   justify-content: flex-end;
		   gap: 12px;
		   margin-top: 22px;
	   }
	   .uv-btn-cancel {
		   padding: 10px 22px;
		   font-size: 1.08rem;
		   font-weight: 600;
		   background: #ede9fe;
		   color: #7c3aed;
		   border: none;
		   border-radius: 10px;
		   box-shadow: 0 2px 8px rgba(124,58,237,0.10);
		   transition: background 0.18s, box-shadow 0.18s, color 0.18s;
		   cursor: pointer;
		   outline: none;
	   }
	   .uv-btn-cancel:hover {
		   background: #c7d2fe;
		   color: #4f46e5;
	   }
	   .uv-btn-submit {
		   padding: 10px 22px;
		   font-size: 1.08rem;
		   font-weight: 600;
		   background: #4f46e5;
		   color: #fff;
		   border: none;
		   border-radius: 10px;
		   box-shadow: 0 2px 8px rgba(79,70,229,0.10);
		   transition: background 0.18s, box-shadow 0.18s;
		   cursor: pointer;
		   outline: none;
	   }
	   .uv-btn-submit:hover {
		   background: #312e81;
	   }
	   @keyframes pop {
		   from { transform: scale(0.95); opacity: 0; }
		   to   { transform: scale(1); opacity: 1; }
	   }
	</style>
	<script>
	// Facility search filter
	document.addEventListener('DOMContentLoaded', function() {
		var search = document.getElementById('facilitySearch');
		if (search) {
			search.addEventListener('input', function() {
				var filter = search.value.toLowerCase();
				document.querySelectorAll('#facilityCheckboxList .facility-checkbox-item').forEach(function(item) {
					var label = item.textContent.toLowerCase();
					item.style.display = label.includes(filter) ? '' : 'none';
				});
			});
		}
	});
	</script>


	   <!-- USER VIEW MODAL (modern/professional) -->
	   <div class="modal-backdrop" id="userViewModalBackdrop" onclick="closeUserViewModal()" style="display:none;"></div>
	   <div class="modal-sheet" id="userViewModalSheet" aria-hidden="true" style="display:none;">
		   <div class="modal-card user-view-modal-pro" role="dialog" aria-modal="true">
			   <button type="button" class="modal-close-pro" onclick="closeUserViewModal()" aria-label="Close">&times;</button>
			   <div class="uv-modal-header">
				   <h2 class="uv-modal-title" id="userViewModalTitle">User Details</h2>
				   <div class="uv-modal-subtitle" id="userViewModalSubtitle">View user information and assigned facility.</div>
			   </div>
			   <div class="uv-modal-content">
				   <div class="uv-modal-row"><span class="uv-label">Full Name</span><span class="uv-value" id="uv_full_name">-</span></div>
				   <div class="uv-modal-row"><span class="uv-label">Email</span><span class="uv-value" id="uv_email">-</span></div>
				   <div class="uv-modal-row"><span class="uv-label">Username</span><span class="uv-value" id="uv_username">-</span></div>
				   <div class="uv-modal-row"><span class="uv-label">Role</span><span class="uv-value" id="uv_role">-</span></div>
				   <div class="uv-modal-row"><span class="uv-label">Status</span><span class="uv-value" id="uv_status">-</span></div>
				   <div class="uv-modal-row" style="align-items:flex-start;">
					   <span class="uv-label">Assigned Facilities</span>
					   <span class="uv-value" id="uv_facilities" style="display:block;max-width:260px;">
						   <!-- Facilities will be rendered here as badges -->
					   </span>
				   </div>
				   <div class="uv-modal-row"><span class="uv-label">Department</span><span class="uv-value" id="uv_department">-</span></div>
				   <div class="uv-modal-row"><span class="uv-label">Contact Number</span><span class="uv-value" id="uv_contact_number">-</span></div>
			   </div>
			   <div class="uv-modal-actions">
				   <button type="button" class="uv-btn-close" onclick="closeUserViewModal()">Close</button>
			   </div>
		   </div>
	   </div>

	   <style>
	   .user-view-modal-pro {
		   max-width: 420px;
		   width: 100%;
		   margin: 60px auto;
		   background: #fff;
		   border-radius: 18px;
		   box-shadow: 0 8px 32px rgba(49,46,129,0.13), 0 2px 8px rgba(30,41,59,0.07);
		   padding: 0 0 18px 0;
		   position: relative;
		   animation: pop 0.22s cubic-bezier(.4,2,.6,1);
	   }
	   .modal-close-pro {
		   position: absolute;
		   top: 18px;
		   right: 22px;
		   background: none;
		   border: none;
		   font-size: 2.1rem;
		   color: #64748b;
		   cursor: pointer;
		   border-radius: 50%;
		   width: 38px;
		   height: 38px;
		   display: flex;
		   align-items: center;
		   justify-content: center;
		   transition: background 0.18s, color 0.18s;
	   }
	   .modal-close-pro:hover {
		   background: #e0e7ef;
		   color: #e11d48;
	   }
	   .uv-modal-header {
		   padding: 38px 38px 0 38px;
		   text-align: center;
	   }
	   .uv-modal-title {
		   font-size: 1.45rem;
		   font-weight: 800;
		   color: #312e81;
		   margin-bottom: 2px;
	   }
	   .uv-modal-subtitle {
		   font-size: 1.08rem;
		   color: #6366f1;
		   font-weight: 500;
		   margin-bottom: 18px;
	   }
	   .uv-modal-content {
		   padding: 0 38px;
		   display: flex;
		   flex-direction: column;
		   gap: 12px;
	   }
	   .uv-modal-row {
		   display: flex;
		   justify-content: space-between;
		   align-items: flex-start;
		   padding: 8px 0;
		   border-bottom: 1px solid #f1f5f9;
		   font-size: 1.05rem;
	   }
	   .uv-modal-row:last-child {
		   border-bottom: none;
	   }
	   .uv-label {
		   color: #64748b;
		   font-weight: 600;
		   min-width: 120px;
	   }
	   .uv-value {
		   color: #111827;
		   font-weight: 700;
		   word-break: break-all;
		   text-align: right;
	   }
	   #uv_facilities {
		   display: flex;
		   flex-wrap: wrap;
		   gap: 8px 10px;
		   max-height: 120px;
		   overflow-y: auto;
		   align-items: flex-start;
		   justify-content: flex-start;
		   margin-top: 2px;
	   }
	   .facility-badge {
		   background: #f3f4f6;
		   padding: 4px 14px;
		   border-radius: 999px;
		   font-size: 1rem;
		   color: #312e81;
		   font-weight: 600;
		   margin-bottom: 6px;
		   margin-right: 0px;
		   white-space: nowrap;
		   box-shadow: 0 0 0 1px rgba(49,46,129,0.06);
	   }
	   .uv-modal-actions {
		   display: flex;
		   justify-content: flex-end;
		   padding: 0 38px;
		   margin-top: 18px;
	   }
	   .uv-btn-close {
		   padding: 10px 22px;
		   font-size: 1.08rem;
		   font-weight: 600;
		   background: #ede9fe;
		   color: #7c3aed;
		   border: none;
		   border-radius: 10px;
		   box-shadow: 0 2px 8px rgba(124,58,237,0.10);
		   transition: background 0.18s, box-shadow 0.18s, color 0.18s;
		   cursor: pointer;
		   outline: none;
	   }
	   .uv-btn-close:hover {
		   background: #c7d2fe;
		   color: #4f46e5;
	   }
	   @keyframes pop {
		   from { transform: scale(0.95); opacity: 0; }
		   to   { transform: scale(1); opacity: 1; }
	   }
	   </style>

	<script>
	function openUserModal() {
		document.getElementById('userModalBackdrop').style.display = 'block';
		document.getElementById('userModalSheet').style.display = 'block';
		document.getElementById('userModalSheet').setAttribute('aria-hidden', 'false');
	}

	function closeUserModal() {
		document.getElementById('userModalBackdrop').style.display = 'none';
		document.getElementById('userModalSheet').style.display = 'none';
		document.getElementById('userModalSheet').setAttribute('aria-hidden', 'true');
	}

	function openUserViewModal() {
		document.getElementById('userViewModalBackdrop').style.display = 'block';
		document.getElementById('userViewModalSheet').style.display = 'block';
		document.getElementById('userViewModalSheet').setAttribute('aria-hidden', 'false');
	}

	function closeUserViewModal() {
		document.getElementById('userViewModalBackdrop').style.display = 'none';
		document.getElementById('userViewModalSheet').style.display = 'none';
		document.getElementById('userViewModalSheet').setAttribute('aria-hidden', 'true');
	}

	function toggleUserModalFacility() {
		const role = (document.getElementById('um_role').value || '').toLowerCase();
		const facilityWrap = document.getElementById('um_facility_wrap');
		if (role === 'staff') {
			facilityWrap.style.display = 'block';
		} else {
			facilityWrap.style.display = 'none';
			document.querySelectorAll('input[name="facility_id[]"]').forEach(cb => { cb.checked = false; });
		}
	}

	function generateUserModalStrongPassword(length) {
		var targetLength = Math.max(12, Number(length || 14));
		var upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
		var lower = 'abcdefghijkmnopqrstuvwxyz';
		var number = '23456789';
		var symbol = '!@#$%^&*_-+=?';
		var all = upper + lower + number + symbol;

		function pick(str) {
			return str.charAt(Math.floor(Math.random() * str.length));
		}

		var chars = [
			pick(upper),
			pick(lower),
			pick(number),
			pick(symbol)
		];

		while (chars.length < targetLength) {
			chars.push(pick(all));
		}

		for (var i = chars.length - 1; i > 0; i--) {
			var j = Math.floor(Math.random() * (i + 1));
			var tmp = chars[i];
			chars[i] = chars[j];
			chars[j] = tmp;
		}

		return chars.join('');
	}

	function resetUserModalPasswordUi() {
		var autoToggle = document.getElementById('um_password_autogen_toggle');
		var generateBtn = document.getElementById('um_password_generate_btn');
		var passwordInput = document.getElementById('um_password');
		var confirmInput = document.getElementById('um_password_confirmation');
		var toggleBtns = [
			document.getElementById('um_password_toggle_btn'),
			document.getElementById('um_password_confirmation_toggle_btn')
		];

		if (autoToggle) autoToggle.checked = false;
		if (generateBtn) generateBtn.style.display = 'none';
		if (passwordInput) passwordInput.type = 'password';
		if (confirmInput) confirmInput.type = 'password';
		toggleBtns.forEach(function(btn) {
			if (btn) btn.textContent = 'Show';
		});
	}

	function generateUserModalPassword() {
		var passwordInput = document.getElementById('um_password');
		var confirmInput = document.getElementById('um_password_confirmation');
		if (!passwordInput || !confirmInput) return;

		var generated = generateUserModalStrongPassword(14);
		passwordInput.value = generated;
		confirmInput.value = generated;
	}

	function handleUserModalAutoPasswordToggle() {
		var autoToggle = document.getElementById('um_password_autogen_toggle');
		var generateBtn = document.getElementById('um_password_generate_btn');
		var passwordInput = document.getElementById('um_password');
		var confirmInput = document.getElementById('um_password_confirmation');
		if (!autoToggle || !generateBtn || !passwordInput || !confirmInput) return;

		generateBtn.style.display = autoToggle.checked ? 'inline-flex' : 'none';

		if (autoToggle.checked) {
			generateUserModalPassword();
		} else {
			passwordInput.value = '';
			confirmInput.value = '';
		}
	}

	function toggleUserModalPasswordVisibility(inputId, btn) {
		var input = document.getElementById(inputId);
		if (!input || !btn) return;

		var show = input.type === 'password';
		input.type = show ? 'text' : 'password';
		btn.textContent = show ? 'Hide' : 'Show';
	}

	function resetUserModalFields() {
		document.getElementById('um_full_name').value = '';
		document.getElementById('um_email').value = '';
		document.getElementById('um_username').value = '';
		document.getElementById('um_role').value = '';
		document.getElementById('um_status').value = 'active';
		document.querySelectorAll('input[name="facility_id[]"]').forEach(cb => { cb.checked = false; });
		document.getElementById('um_department').value = '';
		document.getElementById('um_contact_number').value = '';
		document.getElementById('um_password').value = '';
		document.getElementById('um_password_confirmation').value = '';
		resetUserModalPasswordUi();
		toggleUserModalFacility();
	}

	function openUserModalCreate() {
		resetUserModalFields();
		document.getElementById('userModalTitle').textContent = 'Create User';
		document.getElementById('userModalSubtitle').textContent = 'Add a new system user and optionally assign a facility (Staff only).';
		document.getElementById('userModalSubmitBtn').textContent = 'Create User';

		const form = document.getElementById('userModalForm');
		form.action = "{{ route('users.store') }}";
		document.getElementById('userModalMethod').value = '';

		// Password required on create
		document.getElementById('um_password_block').style.display = 'block';
		document.getElementById('um_password_tools').style.display = 'flex';
		document.getElementById('um_password').required = true;
		document.getElementById('um_password_confirmation').required = true;
		document.getElementById('um_password_label').textContent = 'Password *';
		document.getElementById('um_password_confirmation_label').textContent = 'Confirm Password *';
		document.getElementById('um_password_hint').textContent = 'Password is required when creating a new user.';

		openUserModal();
	}

	function openUserModalEdit(el) {
		resetUserModalFields();
		document.getElementById('userModalTitle').textContent = 'Edit User';
		document.getElementById('userModalSubtitle').textContent = 'Update user information and facility assignment.';
		document.getElementById('userModalSubmitBtn').textContent = 'Update User';

		const payloadRaw = el.getAttribute('data-user') || '{}';
		let payload = {};
		try { payload = JSON.parse(payloadRaw); } catch (e) { 
			console.error('Error parsing user data:', e);
			payload = {}; 
		}

		const userId = el.getAttribute('data-user-id') || payload.id || '';
		if (!userId) {
			console.error('Missing user id for edit modal.');
			return;
		}
		const fullName = payload.full_name || '';
		const email = payload.email || '';
		const username = payload.username || '';
		const role = (payload.role || '').toLowerCase();
		const status = (payload.status || 'active').toLowerCase();
		const facilityIds = Array.isArray(payload.facility_ids) ? payload.facility_ids.map(String) : [];
		const department = payload.department || '';
		const contactNumber = payload.contact_number || '';

		// Populate all fields
		document.getElementById('um_full_name').value = fullName;
		document.getElementById('um_email').value = email;
		document.getElementById('um_username').value = username;
		document.getElementById('um_role').value = role;
		document.getElementById('um_status').value = status;
		document.getElementById('um_department').value = department;
		document.getElementById('um_contact_number').value = contactNumber;
        
		   // Set facility checkboxes for multiple facilities
		   document.querySelectorAll('input[name="facility_id[]"]').forEach(cb => {
			   cb.checked = facilityIds.includes(cb.value);
		   });

		// Toggle facility field visibility based on role
		toggleUserModalFacility();

		const form = document.getElementById('userModalForm');
		form.action = "{{ url('modules/users') }}/" + userId;
		document.getElementById('userModalMethod').value = 'PUT';

		// Password is optional on edit
		document.getElementById('um_password_block').style.display = 'block';
		document.getElementById('um_password_tools').style.display = 'none';
		document.getElementById('um_password').required = false;
		document.getElementById('um_password_confirmation').required = false;
		document.getElementById('um_password_label').textContent = 'Password (optional)';
		document.getElementById('um_password_confirmation_label').textContent = 'Confirm Password (optional)';
		document.getElementById('um_password_hint').textContent = 'Leave password fields blank if you do not want to change the current password.';

		openUserModal();
	}

	function openUserModalView(el) {
		const payloadRaw = el.getAttribute('data-user') || '{}';
		let payload = {};
		try { payload = JSON.parse(payloadRaw); } catch (e) {
			console.error('Error parsing user data:', e);
			payload = {};
		}

		const clean = (val) => (val !== null && val !== undefined && val !== '') ? val : '-';


		   document.getElementById('uv_full_name').textContent = clean(payload.full_name);
		   document.getElementById('uv_email').textContent = clean(payload.email);
		   document.getElementById('uv_username').textContent = clean(payload.username);
		   document.getElementById('uv_role').textContent = clean(payload.role);
		   document.getElementById('uv_status').textContent = clean(payload.status);
		   const facilitiesElem = document.getElementById('uv_facilities');
		   if (Array.isArray(payload.facilities) && payload.facilities.length) {
			   facilitiesElem.innerHTML = '';
			   payload.facilities.forEach(function(name) {
				   const badge = document.createElement('span');
				   badge.className = 'facility-badge';
				   badge.textContent = name;
				   facilitiesElem.appendChild(badge);
			   });
		   } else {
			   facilitiesElem.textContent = '-';
		   }
		   document.getElementById('uv_department').textContent = clean(payload.department);
		   document.getElementById('uv_contact_number').textContent = clean(payload.contact_number);

		openUserViewModal();
	}

	// ESC to close
	document.addEventListener('keydown', function(e){
		if (e.key === 'Escape') closeUserModal();
	});

	document.addEventListener('DOMContentLoaded', function () {
		var autoToggle = document.getElementById('um_password_autogen_toggle');
		if (autoToggle) {
			autoToggle.addEventListener('change', handleUserModalAutoPasswordToggle);
		}
	});

	</script>
@endif
</div>
@endsection
