@extends('layouts.qc-admin')
@section('title', 'Energy Monitoring Dashboard')

<style>
    .skip-link {
        position: absolute;
        left: -999px;
        top: 10px;
        background: #3762c8;
        color: #fff;
        padding: 8px 16px;
        z-index: 10000;
        border-radius: 6px;
        font-weight: 600;
        transition: left 0.2s;
    }
    .skip-link:focus { left: 10px; }

    .energy-monitor-page .report-card {
        background: linear-gradient(165deg, #ffffff 0%, #f8fbff 100%);
        border-radius: 16px;
        box-shadow: 0 14px 32px rgba(15, 23, 42, 0.08);
        padding: 30px;
        border: 1px solid #e7eef8;
        margin-bottom: 2rem;
    }

    .energy-monitor-page .monitor-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 25px;
        gap: 20px;
        flex-wrap: wrap;
    }

    .energy-monitor-page .monitor-title {
        margin: 0;
        font-size: 1.8rem;
        color: #1e293b;
        font-weight: 800;
        letter-spacing: -0.5px;
    }

    .energy-monitor-page .monitor-title-accent {
        color: #2563eb;
    }

    .energy-monitor-page .monitor-subtitle {
        margin: 4px 0 0;
        color: #64748b;
        font-size: 1rem;
    }

    .energy-monitor-page .search-form {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
    }

    .energy-monitor-page .search-field {
        position: relative;
    }

    .energy-monitor-page .period-field {
        display: flex;
        align-items: center;
    }

    .energy-monitor-page .search-input {
        border-radius: 10px;
        border: 1px solid #e2e8f0;
        padding: 10px 10px 10px 35px;
        font-size: 0.9rem;
        width: 220px;
        outline: none;
        transition: border-color 0.2s, box-shadow 0.2s;
        background: #fff;
        color: #0f172a;
    }

    .energy-monitor-page .period-input {
        border-radius: 10px;
        border: 1px solid #e2e8f0;
        padding: 10px 12px;
        font-size: 0.9rem;
        width: 165px;
        outline: none;
        transition: border-color 0.2s, box-shadow 0.2s;
        background: #fff;
        color: #0f172a;
    }

    .energy-monitor-page .search-input:focus {
        border-color: #60a5fa;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.16);
    }

    .energy-monitor-page .period-input:focus {
        border-color: #60a5fa;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.16);
    }

    .energy-monitor-page .search-btn {
        background: #2563eb;
        color: #fff;
        border: none;
        border-radius: 10px;
        padding: 10px 20px;
        font-weight: 600;
        cursor: pointer;
        transition: transform 0.15s ease, box-shadow 0.15s ease;
    }

    .energy-monitor-page .search-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 8px 18px rgba(37, 99, 235, 0.25);
    }

    .energy-monitor-page .clear-link {
        color: #e11d48;
        text-decoration: none;
        font-weight: 600;
        font-size: 0.9rem;
    }

    .energy-monitor-page .overview-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .energy-monitor-page .metric-card {
        padding: 20px;
        border-radius: 14px;
        border-left: 4px solid transparent;
        border: 1px solid transparent;
        box-shadow: 0 8px 20px rgba(15, 23, 42, 0.05);
    }

    .energy-monitor-page .metric-card .metric-label {
        font-weight: 700;
        font-size: 0.75rem;
        text-transform: uppercase;
        margin-bottom: 8px;
        letter-spacing: 0.4px;
    }

    .energy-monitor-page .metric-card .metric-value {
        font-weight: 800;
        font-size: 1.8rem;
        color: #1e293b;
    }

    .energy-monitor-page .metric-meta {
        margin-top: 5px;
        color: #64748b;
        font-size: 0.76rem;
        font-weight: 600;
    }

    .energy-monitor-page .metric-facilities {
        background: linear-gradient(140deg, #f4f9ff, #f8fbff);
        border-color: #dbeafe;
        border-left-color: #2563eb;
    }
    .energy-monitor-page .metric-facilities .metric-label { color: #64748b; }

    .energy-monitor-page .metric-alert {
        background: linear-gradient(140deg, #fff3f5, #fff7f8);
        border-color: #fecdd3;
        border-left-color: #e11d48;
    }
    .energy-monitor-page .metric-alert .metric-label { color: #e11d48; }

    .energy-monitor-page .metric-cost {
        background: linear-gradient(140deg, #f2fdf7, #f8fffb);
        border-color: #bbf7d0;
        border-left-color: #16a34a;
    }
    .energy-monitor-page .metric-cost .metric-label { color: #166534; }

    .energy-monitor-page .monitor-table-wrap {
        overflow-x: auto;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        background: #fff;
    }

    .energy-monitor-page .monitor-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        min-width: 820px;
        font-size: 0.86rem;
    }

    .energy-monitor-page .monitor-table thead tr {
        background: #f1f5f9;
    }

    .energy-monitor-page .monitor-table th {
        padding: 11px 8px;
        color: #475569;
        font-weight: 700;
        text-align: center;
        border-bottom: 1px solid #e2e8f0;
        line-height: 1.25;
    }

    .energy-monitor-page .monitor-table th:first-child {
        border-radius: 10px 0 0 0;
    }

    .energy-monitor-page .monitor-table th:last-child {
        border-radius: 0 10px 0 0;
    }

    .energy-monitor-page .monitor-table td {
        padding: 11px 8px;
        text-align: center;
        border-bottom: 1px solid #f1f5f9;
        color: #334155;
        line-height: 1.3;
    }

    .energy-monitor-page .monitor-row:hover {
        background: #fafcff;
    }

    .energy-monitor-page .cell-facility {
        font-weight: 700;
        color: #334155;
    }

    .energy-monitor-page .cell-type {
        color: #64748b;
    }

    .energy-monitor-page .cell-baseline {
        color: #2563eb;
        font-weight: 600;
    }

    .energy-monitor-page .cell-meter-name {
        font-weight: 700;
        color: #0f172a;
    }

    .energy-monitor-page .cell-meter-meta {
        margin-top: 3px;
        font-size: 0.72rem;
        color: #64748b;
    }

    .energy-monitor-page .cell-meter-alert-summary {
        margin-top: 4px;
    }

    .energy-monitor-page .cell-meter-hint {
        font-size: 0.72rem;
        color: inherit;
        font-weight: 700;
    }

    .energy-monitor-page .main-meter-trigger {
        margin-top: 5px;
        padding: 4px 8px;
        border: 1px solid #bfdbfe;
        border-radius: 999px;
        background: #eff6ff;
        color: #2563eb;
        font-weight: 700;
        font-size: 0.72rem;
        cursor: pointer;
    }

    .energy-monitor-page .main-meter-trigger:hover {
        background: #dbeafe;
        color: #1d4ed8;
    }

    .energy-monitor-page .cell-reading-note {
        display: block;
        margin-top: 3px;
        color: #64748b;
        font-size: 0.72rem;
        font-weight: 700;
    }

    .energy-monitor-page .monitor-row-seeded {
        background: linear-gradient(90deg, #eff6ff 0%, #f8fafc 100%);
    }

    .energy-monitor-page .monitor-row-seeded:hover {
        background: linear-gradient(90deg, #dbeafe 0%, #f8fafc 100%);
    }

    .energy-monitor-page .seeded-facility-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin-top: 6px;
        padding: 4px 10px;
        border-radius: 999px;
        border: 1px solid rgba(37, 99, 235, 0.18);
        background: rgba(37, 99, 235, 0.08);
        color: #1d4ed8;
        font-size: 0.72rem;
        font-weight: 800;
    }

    .energy-monitor-page .trend-value {
        font-weight: 700;
    }

    .energy-monitor-page .trend-positive {
        color: #e11d48;
    }

    .energy-monitor-page .trend-normal {
        color: #16a34a;
    }

    .energy-monitor-page .unit-label {
        color: #64748b;
        font-size: 0.82rem;
    }

    .energy-monitor-page .alert-pill-level-critical {
        color: #7c1d1d;
        background: #fef2f2;
        border-color: rgba(124, 29, 29, 0.2);
    }

    .energy-monitor-page .alert-pill-level-very-high {
        color: #be123c;
        background: #fff1f2;
        border-color: rgba(190, 18, 60, 0.2);
    }

    .energy-monitor-page .alert-pill-level-high {
        color: #c2410c;
        background: #fff7ed;
        border-color: rgba(194, 65, 12, 0.2);
    }

    .energy-monitor-page .alert-pill-level-moderate,
    .energy-monitor-page .alert-pill-level-warning {
        color: #b45309;
        background: #fffbeb;
        border-color: rgba(180, 83, 9, 0.22);
    }

    .energy-monitor-page .alert-pill-level-low,
    .energy-monitor-page .alert-pill-level-normal {
        color: #166534;
        background: #f0fdf4;
        border-color: rgba(22, 101, 52, 0.2);
    }

    .energy-monitor-page .alert-pill-level-no-data {
        color: #475569;
        background: #f1f5f9;
        border-color: rgba(100, 116, 139, 0.22);
    }

    .energy-monitor-page .recommendation-btn.level-critical,
    .energy-monitor-page .recommendation-btn.level-very-high {
        color: #e11d48;
    }

    .energy-monitor-page .recommendation-btn.level-high,
    .energy-monitor-page .recommendation-btn.level-warning,
    .energy-monitor-page .recommendation-btn.level-moderate {
        color: #f59e42;
    }

    .energy-monitor-page .recommendation-btn.level-low,
    .energy-monitor-page .recommendation-btn.level-normal {
        color: #16a34a;
    }

    .energy-monitor-page .recommendation-btn.level-no-data {
        color: #64748b;
    }

    .energy-monitor-page .recommendation-icon {
        font-size: 1.08rem;
    }

    .energy-monitor-page .monitor-empty {
        padding: 50px;
        text-align: center;
        color: #94a3b8;
    }

    .energy-monitor-page .recommendation-modal {
        display: none;
        position: fixed;
        z-index: 10060;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0,0,0,0.18);
        justify-content: center;
        align-items: center;
    }

    .energy-monitor-page .recommendation-modal-inner {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100vw;
        height: 100vh;
        padding: 18px;
    }

    .energy-monitor-page .recommendation-modal-panel {
        width: min(500px, 100%);
        background: #ffffff;
        border-radius: 22px;
        box-shadow: 0 18px 42px rgba(15, 23, 42, 0.16);
        border: 1px solid #e2e8f0;
        padding: 22px 22px 18px;
        position: relative;
    }

    .energy-monitor-page .recommendation-modal-header {
        display: flex;
        align-items: flex-start;
        justify-content: flex-start;
        gap: 12px;
        margin-bottom: 16px;
        padding-right: 34px;
    }

    .energy-monitor-page .recommendation-title-wrap {
        min-width: 0;
    }

    .energy-monitor-page .recommendation-title {
        margin: 0;
        font-size: 1.18rem;
        font-weight: 800;
        line-height: 1.45;
        color: #0f172a;
    }

    .energy-monitor-page .recommendation-meta {
        display: none;
        margin-top: 6px;
        width: fit-content;
        padding: 4px 9px;
        border-radius: 999px;
        font-size: 0.7rem;
        color: #475569;
        background: #f1f5f9;
        border: 1px solid #cbd5e1;
        font-weight: 800;
        letter-spacing: 0.02em;
    }

    .energy-monitor-page .recommendation-meta.source-ai {
        color: #1d4ed8;
        background: #eff6ff;
        border-color: #93c5fd;
    }

    .energy-monitor-page .recommendation-meta.source-system {
        color: #475569;
        background: #f8fafc;
        border-color: #cbd5e1;
    }

    .energy-monitor-page .recommendation-alert-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 34px;
        height: 34px;
        border-radius: 999px;
        font-size: 1rem;
        font-weight: 800;
        flex-shrink: 0;
        background: #ffffff;
        border: 1.5px solid #cbd5e1;
    }

    .energy-monitor-page .recommendation-message-card {
        border-radius: 14px;
        padding: 16px 18px;
        border: 1px solid transparent;
        font-size: 0.96rem;
        line-height: 1.5;
        font-weight: 700;
        white-space: normal;
        word-break: break-word;
    }

    .energy-monitor-page .recommendation-close-icon {
        position: absolute;
        top: 12px;
        right: 14px;
        width: auto;
        height: auto;
        border-radius: 0;
        font-size: 1.5rem;
        line-height: 1;
        background: transparent;
        border: none;
        color: #64748b;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: color .16s ease, transform .16s ease;
    }

    .energy-monitor-page .recommendation-close-icon:hover {
        color: #475569;
        transform: scale(1.05);
    }

    .energy-monitor-page .recommendation-close-btn {
        background: linear-gradient(90deg, #2563eb, #1d4ed8);
        color: #fff;
        padding: 9px 18px;
        border: none;
        border-radius: 10px;
        font-weight: 700;
        font-size: 0.9rem;
        cursor: pointer;
        box-shadow: none;
    }

    .energy-monitor-page .recommendation-footer {
        margin-top: 14px;
        display: flex;
        justify-content: flex-end;
    }

    .energy-monitor-page .meter-breakdown-total {
        margin-bottom: 14px;
        padding: 14px 16px;
        border-radius: 14px;
        border: 1px solid #dbeafe;
        background: linear-gradient(145deg, #eff6ff, #f8fafc);
    }

    .energy-monitor-page .meter-breakdown-total-label {
        font-size: 0.78rem;
        font-weight: 800;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: #2563eb;
    }

    .energy-monitor-page .meter-breakdown-total-value {
        margin-top: 6px;
        font-size: 1.3rem;
        font-weight: 800;
        color: #0f172a;
    }

    .energy-monitor-page .meter-breakdown-list {
        display: grid;
        gap: 12px;
        max-height: 340px;
        overflow-y: auto;
        padding-right: 2px;
    }

    .energy-monitor-page .meter-breakdown-card {
        padding: 14px 16px;
        border-radius: 14px;
        border: 1px solid #e2e8f0;
        background: #f8fafc;
    }

    .energy-monitor-page .meter-breakdown-card-head {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 14px;
    }

    .energy-monitor-page .meter-breakdown-card-title {
        font-size: 0.96rem;
        font-weight: 800;
        color: #0f172a;
    }

    .energy-monitor-page .meter-breakdown-card-subtitle {
        margin-top: 4px;
        font-size: 0.8rem;
        color: #64748b;
        font-weight: 600;
    }

    .energy-monitor-page .meter-breakdown-card-kwh {
        text-align: right;
        font-size: 1rem;
        font-weight: 800;
        color: #1d4ed8;
        white-space: nowrap;
    }

    .energy-monitor-page .meter-breakdown-card-kwh small {
        display: block;
        margin-top: 4px;
        font-size: 0.72rem;
        font-weight: 700;
        color: #64748b;
    }

    .energy-monitor-page .meter-breakdown-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 12px;
    }

    .energy-monitor-page .meter-breakdown-pill {
        display: inline-flex;
        align-items: center;
        padding: 6px 10px;
        border-radius: 999px;
        border: 1px solid #cbd5e1;
        background: #ffffff;
        color: #475569;
        font-size: 0.74rem;
        font-weight: 700;
    }

    .energy-monitor-page .monitor-alert-pill {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 3px 8px;
        border-radius: 20px;
        font-size: 0.72rem;
        font-weight: 700;
        border: 1px solid transparent;
    }

    .energy-monitor-page .meter-status-pill {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 3px 8px;
        border-radius: 20px;
        font-size: 0.72rem;
        font-weight: 700;
        border: 1px solid transparent;
    }

    .energy-monitor-page .meter-status-pill.status-active {
        color: #166534;
        background: #f0fdf4;
        border-color: rgba(22, 101, 52, 0.2);
    }

    .energy-monitor-page .meter-status-pill.status-all-active {
        color: #166534;
        background: #dcfce7;
        border-color: rgba(22, 101, 52, 0.22);
    }

    .energy-monitor-page .meter-status-pill.status-inactive {
        color: #991b1b;
        background: #fef2f2;
        border-color: rgba(153, 27, 27, 0.2);
    }

    .energy-monitor-page .meter-status-pill.status-all-inactive {
        color: #991b1b;
        background: #fee2e2;
        border-color: rgba(153, 27, 27, 0.22);
    }

    .energy-monitor-page .meter-status-pill.status-maintenance,
    .energy-monitor-page .meter-status-pill.status-pending-approval {
        color: #9a3412;
        background: #fff7ed;
        border-color: rgba(154, 52, 18, 0.2);
    }

    .energy-monitor-page .meter-status-pill.status-all-maintenance,
    .energy-monitor-page .meter-status-pill.status-mixed-status {
        color: #1d4ed8;
        background: #eff6ff;
        border-color: rgba(29, 78, 216, 0.2);
    }

    .energy-monitor-page .meter-status-pill.status-no-main-meter,
    .energy-monitor-page .meter-status-pill.status-unknown {
        color: #475569;
        background: #f1f5f9;
        border-color: rgba(100, 116, 139, 0.22);
    }

    .energy-monitor-page .facility-status-cluster {
        display: flex;
        flex-wrap: wrap;
        gap: 5px;
        justify-content: center;
    }

    .energy-monitor-page .facility-status-pill {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 3px 8px;
        border-radius: 20px;
        font-size: 0.7rem;
        font-weight: 700;
        border: 1px solid transparent;
        white-space: nowrap;
    }

    .energy-monitor-page .facility-status-pill.status-facility-active,
    .energy-monitor-page .facility-status-pill.status-maintenance-logged {
        color: #166534;
        background: #f0fdf4;
        border-color: rgba(22, 101, 52, 0.2);
    }

    .energy-monitor-page .facility-status-pill.status-facility-inactive {
        color: #991b1b;
        background: #fef2f2;
        border-color: rgba(153, 27, 27, 0.2);
    }

    .energy-monitor-page .facility-status-pill.status-facility-maintenance,
    .energy-monitor-page .facility-status-pill.status-maintenance-ongoing {
        color: #9a3412;
        background: #fff7ed;
        border-color: rgba(154, 52, 18, 0.2);
    }

    .energy-monitor-page .facility-status-pill.status-no-maintenance-log,
    .energy-monitor-page .facility-status-pill.status-facility-unknown {
        color: #475569;
        background: #f1f5f9;
        border-color: rgba(100, 116, 139, 0.22);
    }

    .energy-monitor-page .recommendation-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        background: #eff6ff;
        border: 1px solid #bfdbfe;
        border-radius: 8px;
        color: #1d4ed8;
        font-size: 0.76rem;
        font-weight: 800;
        cursor: pointer;
        padding: 7px 10px;
        white-space: nowrap;
    }

    .energy-monitor-page .pagination-wrap {
        margin-top: 20px;
        display: flex;
        justify-content: center;
    }

    body.dark-mode .energy-monitor-page .report-card {
        background: #0f172a !important;
        border-color: #334155 !important;
        box-shadow: 0 18px 34px rgba(2, 6, 23, 0.5);
    }

    body.dark-mode .energy-monitor-page .monitor-title,
    body.dark-mode .energy-monitor-page .metric-value,
    body.dark-mode .energy-monitor-page .monitor-table td {
        color: #e2e8f0 !important;
    }

    body.dark-mode .energy-monitor-page .monitor-subtitle,
    body.dark-mode .energy-monitor-page .metric-label,
    body.dark-mode .energy-monitor-page .monitor-table th {
        color: #94a3b8 !important;
    }

    body.dark-mode .energy-monitor-page .clear-link {
        color: #fda4af;
    }

    body.dark-mode .energy-monitor-page .search-input {
        background: #0b1220 !important;
        color: #e2e8f0 !important;
        border-color: #334155 !important;
    }

    body.dark-mode .energy-monitor-page .search-input::placeholder {
        color: #64748b;
    }

    body.dark-mode .energy-monitor-page .search-btn {
        background: #1d4ed8 !important;
    }

    body.dark-mode .energy-monitor-page .search-btn:hover {
        box-shadow: 0 8px 18px rgba(37, 99, 235, 0.4);
    }

    body.dark-mode .energy-monitor-page .monitor-table thead tr {
        background: #111827 !important;
    }

    body.dark-mode .energy-monitor-page .monitor-table th,
    body.dark-mode .energy-monitor-page .monitor-table td {
        border-color: #334155 !important;
    }

    body.dark-mode .energy-monitor-page .monitor-table-wrap {
        background: #0f172a;
        border-color: #334155;
    }

    body.dark-mode .energy-monitor-page .monitor-row:hover {
        background: #1f2937 !important;
    }

    body.dark-mode .energy-monitor-page .cell-type,
    body.dark-mode .energy-monitor-page .unit-label {
        color: #94a3b8;
    }

    body.dark-mode .energy-monitor-page .cell-baseline {
        color: #93c5fd;
    }

    body.dark-mode .energy-monitor-page .cell-meter-name {
        color: #f8fafc;
    }

    body.dark-mode .energy-monitor-page .cell-meter-meta {
        color: #94a3b8;
    }

    body.dark-mode .energy-monitor-page .cell-reading-note {
        color: #94a3b8;
    }

    body.dark-mode .energy-monitor-page .cell-meter-hint {
        color: #93c5fd;
    }

    body.dark-mode .energy-monitor-page .main-meter-trigger {
        background: rgba(37, 99, 235, 0.16);
        border-color: rgba(147, 197, 253, 0.26);
        color: #93c5fd;
    }

    body.dark-mode .energy-monitor-page .main-meter-trigger:hover {
        background: rgba(37, 99, 235, 0.26);
        color: #bfdbfe;
    }

    body.dark-mode .energy-monitor-page .monitor-row-seeded {
        background: linear-gradient(90deg, rgba(30, 64, 175, 0.18) 0%, rgba(15, 23, 42, 0.92) 100%);
    }

    body.dark-mode .energy-monitor-page .monitor-row-seeded:hover {
        background: linear-gradient(90deg, rgba(37, 99, 235, 0.22) 0%, rgba(31, 41, 55, 0.96) 100%) !important;
    }

    body.dark-mode .energy-monitor-page .seeded-facility-badge {
        background: rgba(37, 99, 235, 0.18);
        color: #bfdbfe;
        border-color: rgba(147, 197, 253, 0.25);
    }

    body.dark-mode .energy-monitor-page .trend-positive {
        color: #fb7185;
    }

    body.dark-mode .energy-monitor-page .trend-normal {
        color: #34d399;
    }

    body.dark-mode .energy-monitor-page .metric-facilities {
        background: linear-gradient(145deg, #102138, #111827) !important;
        border-color: #2f4c72 !important;
    }

    body.dark-mode .energy-monitor-page .metric-alert {
        background: linear-gradient(145deg, #321923, #111827) !important;
        border-color: #7f1d1d !important;
    }

    body.dark-mode .energy-monitor-page .metric-cost {
        background: linear-gradient(145deg, #0f2a22, #111827) !important;
        border-color: #166534 !important;
    }

    body.dark-mode .energy-monitor-page .alert-pill-level-critical {
        color: #fecaca;
        background: rgba(127, 29, 29, 0.35);
        border-color: rgba(248, 113, 113, 0.4);
    }

    body.dark-mode .energy-monitor-page .alert-pill-level-very-high,
    body.dark-mode .energy-monitor-page .alert-pill-level-high {
        color: #fda4af;
        background: rgba(190, 18, 60, 0.25);
        border-color: rgba(244, 114, 182, 0.35);
    }

    body.dark-mode .energy-monitor-page .alert-pill-level-moderate,
    body.dark-mode .energy-monitor-page .alert-pill-level-warning {
        color: #fde68a;
        background: rgba(146, 64, 14, 0.3);
        border-color: rgba(251, 191, 36, 0.35);
    }

    body.dark-mode .energy-monitor-page .alert-pill-level-low,
    body.dark-mode .energy-monitor-page .alert-pill-level-normal {
        color: #86efac;
        background: rgba(22, 101, 52, 0.25);
        border-color: rgba(74, 222, 128, 0.28);
    }

    body.dark-mode .energy-monitor-page .alert-pill-level-no-data {
        color: #cbd5e1;
        background: rgba(51, 65, 85, 0.35);
        border-color: rgba(148, 163, 184, 0.25);
    }

    body.dark-mode .energy-monitor-page .meter-status-pill.status-active {
        color: #86efac;
        background: rgba(22, 101, 52, 0.25);
        border-color: rgba(74, 222, 128, 0.28);
    }

    body.dark-mode .energy-monitor-page .meter-status-pill.status-all-active {
        color: #86efac;
        background: rgba(22, 101, 52, 0.32);
        border-color: rgba(74, 222, 128, 0.32);
    }

    body.dark-mode .energy-monitor-page .meter-status-pill.status-inactive {
        color: #fecaca;
        background: rgba(127, 29, 29, 0.35);
        border-color: rgba(248, 113, 113, 0.35);
    }

    body.dark-mode .energy-monitor-page .meter-status-pill.status-all-inactive {
        color: #fecaca;
        background: rgba(127, 29, 29, 0.42);
        border-color: rgba(248, 113, 113, 0.38);
    }

    body.dark-mode .energy-monitor-page .meter-status-pill.status-maintenance,
    body.dark-mode .energy-monitor-page .meter-status-pill.status-pending-approval {
        color: #fde68a;
        background: rgba(146, 64, 14, 0.3);
        border-color: rgba(251, 191, 36, 0.35);
    }

    body.dark-mode .energy-monitor-page .meter-status-pill.status-all-maintenance,
    body.dark-mode .energy-monitor-page .meter-status-pill.status-mixed-status {
        color: #93c5fd;
        background: rgba(37, 99, 235, 0.2);
        border-color: rgba(147, 197, 253, 0.28);
    }

    body.dark-mode .energy-monitor-page .meter-status-pill.status-no-main-meter,
    body.dark-mode .energy-monitor-page .meter-status-pill.status-unknown {
        color: #cbd5e1;
        background: rgba(51, 65, 85, 0.35);
        border-color: rgba(148, 163, 184, 0.25);
    }

    body.dark-mode .energy-monitor-page .facility-status-pill.status-facility-active,
    body.dark-mode .energy-monitor-page .facility-status-pill.status-maintenance-logged {
        color: #86efac;
        background: rgba(22, 101, 52, 0.25);
        border-color: rgba(74, 222, 128, 0.28);
    }

    body.dark-mode .energy-monitor-page .facility-status-pill.status-facility-inactive {
        color: #fecaca;
        background: rgba(127, 29, 29, 0.35);
        border-color: rgba(248, 113, 113, 0.35);
    }

    body.dark-mode .energy-monitor-page .facility-status-pill.status-facility-maintenance,
    body.dark-mode .energy-monitor-page .facility-status-pill.status-maintenance-ongoing {
        color: #fde68a;
        background: rgba(146, 64, 14, 0.3);
        border-color: rgba(251, 191, 36, 0.35);
    }

    body.dark-mode .energy-monitor-page .facility-status-pill.status-no-maintenance-log,
    body.dark-mode .energy-monitor-page .facility-status-pill.status-facility-unknown {
        color: #cbd5e1;
        background: rgba(51, 65, 85, 0.35);
        border-color: rgba(148, 163, 184, 0.25);
    }

    body.dark-mode .energy-monitor-page .recommendation-modal-panel {
        background: #111827 !important;
        color: #e2e8f0 !important;
        border: 1px solid #334155 !important;
    }

    body.dark-mode .energy-monitor-page .recommendation-title {
        color: #f8fafc !important;
    }

    body.dark-mode .energy-monitor-page .recommendation-meta {
        color: #94a3b8 !important;
    }

    body.dark-mode .energy-monitor-page .recommendation-modal {
        background: rgba(2, 6, 23, 0.6);
    }

    body.dark-mode .energy-monitor-page .recommendation-close-icon {
        color: #94a3b8;
    }

    body.dark-mode .energy-monitor-page .recommendation-close-icon:hover {
        color: #cbd5e1;
    }

    body.dark-mode .energy-monitor-page .recommendation-close-btn {
        background: #1d4ed8;
    }

    body.dark-mode .energy-monitor-page .meter-breakdown-total {
        background: linear-gradient(145deg, #102138, #111827);
        border-color: #2f4c72;
    }

    body.dark-mode .energy-monitor-page .meter-breakdown-total-label {
        color: #93c5fd;
    }

    body.dark-mode .energy-monitor-page .meter-breakdown-total-value,
    body.dark-mode .energy-monitor-page .meter-breakdown-card-title {
        color: #f8fafc;
    }

    body.dark-mode .energy-monitor-page .meter-breakdown-card {
        background: #0f172a;
        border-color: #334155;
    }

    body.dark-mode .energy-monitor-page .meter-breakdown-card-subtitle,
    body.dark-mode .energy-monitor-page .meter-breakdown-card-kwh small {
        color: #94a3b8;
    }

    body.dark-mode .energy-monitor-page .meter-breakdown-card-kwh {
        color: #93c5fd;
    }

    body.dark-mode .energy-monitor-page .meter-breakdown-pill {
        background: #111827;
        border-color: #334155;
        color: #cbd5e1;
    }

    /* Dark mode fallback for remaining inline-styled blocks */
    body.dark-mode .energy-monitor-page [style*="background:#f8fafc"],
    body.dark-mode .energy-monitor-page [style*="background: #f8fafc"] {
        background: linear-gradient(145deg, #102138, #111827) !important;
        border-color: #2f4c72 !important;
    }

    body.dark-mode .energy-monitor-page [style*="background:#fff1f2"],
    body.dark-mode .energy-monitor-page [style*="background: #fff1f2"] {
        background: linear-gradient(145deg, #321923, #111827) !important;
        border-color: #7f1d1d !important;
    }

    body.dark-mode .energy-monitor-page [style*="background:#f0fdf4"],
    body.dark-mode .energy-monitor-page [style*="background: #f0fdf4"] {
        background: linear-gradient(145deg, #0f2a22, #111827) !important;
        border-color: #166534 !important;
    }

    body.dark-mode .energy-monitor-page [style*="background:#f1f5f9"],
    body.dark-mode .energy-monitor-page [style*="background: #f1f5f9"] {
        background: #111827 !important;
    }

    body.dark-mode .energy-monitor-page [style*="border-bottom:1px solid #f1f5f9"] {
        border-bottom: 1px solid #334155 !important;
    }

    body.dark-mode .energy-monitor-page [style*="color:#1e293b"],
    body.dark-mode .energy-monitor-page [style*="color: #1e293b"],
    body.dark-mode .energy-monitor-page [style*="color:#334155"],
    body.dark-mode .energy-monitor-page [style*="color: #334155"] {
        color: #e2e8f0 !important;
    }

    body.dark-mode .energy-monitor-page [style*="color:#64748b"],
    body.dark-mode .energy-monitor-page [style*="color: #64748b"],
    body.dark-mode .energy-monitor-page [style*="color:#475569"],
    body.dark-mode .energy-monitor-page [style*="color: #475569"] {
        color: #94a3b8 !important;
    }

    body.dark-mode .energy-monitor-page [style*="color:#2563eb"],
    body.dark-mode .energy-monitor-page [style*="color: #2563eb"] {
        color: #93c5fd !important;
    }

    body.dark-mode #successAlert > div {
        background: #14532d !important;
        color: #dcfce7 !important;
        border: 1px solid #166534;
    }

    @media (max-width: 600px) {
        .energy-monitor-page .monitor-title { font-size: 1.5rem !important; }
        .energy-monitor-page .overview-cards { grid-template-columns: 1fr; gap: 12px; }
        .energy-monitor-page .report-card { padding: 15px; }
        .energy-monitor-page .search-form { width: 100%; flex-wrap: wrap; }
        .energy-monitor-page .search-field,
        .energy-monitor-page .search-input { width: 100%; }
        .energy-monitor-page .search-btn { width: 100%; }
    }
</style>

@section('content')

@php
    $user = auth()->user();
    $userRole = strtolower($user->role ?? '');
@endphp

<a href="#main-content" class="skip-link" tabindex="0">Skip to main content</a>

{{-- Alerts --}}
@if(session('success'))
<div id="successAlert" style="position:fixed;top:32px;right:32px;z-index:99999;min-width:280px;">
    <div style="background:#dcfce7;color:#166534;padding:16px 24px;border-radius:12px;font-weight:700;box-shadow:0 4px 12px rgba(0,0,0,0.1);display:flex;align-items:center;gap:10px;">
        <i class="fa fa-check-circle" style="color:#22c55e;"></i>
        <span>{{ session('success') }}</span>
    </div>
</div>
@endif

<div class="energy-monitor-page">
<div class="report-card">
    @php
        $dashboardNow = now()->timezone(config('app.timezone', 'Asia/Manila'));
        $selectedMonthInput = $selectedMonthInput ?? $dashboardNow->format('Y-m');
    @endphp
    <div class="monitor-header">
        <div>
            <h1 class="monitor-title">
                Facility Energy Monitoring <span class="monitor-title-accent">Dashboard</span>
            </h1>
            <p class="monitor-subtitle">Period consumption, variance, and facilities requiring attention</p>
        </div>
        
        <form class="search-form" method="GET" action="">
            <div class="period-field">
                <input class="period-input" type="month" name="month" value="{{ $selectedMonthInput }}" aria-label="Filter period month">
            </div>
            <div class="search-field">
                <i class="fa fa-search" style="position:absolute; left:12px; top:50%; transform:translateY(-50%); color:#94a3b8;"></i>
                <input class="search-input" type="text" name="search" value="{{ request('search') }}" placeholder="Search facility...">
            </div>
            <button class="search-btn" type="submit">Apply</button>
            @if(request()->filled('search') || request()->filled('month'))
                <a class="clear-link" href="{{ url()->current() }}">Clear</a>
            @endif
        </form>
    </div>
    <div class="overview-cards">
        <div class="metric-card metric-facilities">
            <div class="metric-label">Main Meter Consumption</div>
            <div class="metric-value">{{ number_format($totalConsumptionKwh ?? 0, 2) }} kWh</div>
            <div class="metric-meta">Across {{ $totalFacilities ?? 0 }} monitored facilities</div>
        </div>
        <div class="metric-card metric-alert">
            <div class="metric-label">Facilities Requiring Attention</div>
            <div class="metric-value">{{ $highAlertCount ?? 0 }}</div>
            <div class="metric-meta">High, very high, or critical alert</div>
        </div>
        <div class="metric-card metric-cost">
            <div class="metric-label">Estimated Energy Cost</div>
            <div class="metric-value">PHP {{ number_format($totalEnergyCost ?? 0, 2) }}</div>
            <div class="metric-meta">For the selected billing period</div>
        </div>
    </div>
    <div class="monitor-table-wrap">
        <table id="main-content" class="monitor-table">
            <thead>
                <tr>
                    <th>Facility</th>
                    <th>Main Meter</th>
                    <th>Consumption</th>
                    <th>Baseline</th>
                    <th>Variance</th>
                    <th>EUI</th>
                    <th>Condition</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            @forelse($facilities as $facility)
                @php 
                    $record = $facility->currentMonthRecord;
                    $trendAnalysis = $facility->trend_analysis ?? '-';
                    $trendSpikeDetected = (bool) ($facility->trend_spike_detected ?? false);
                    $alertLevel = $facility->alert_level ?? 'No Data';
                    $mainMeterLabel = $facility->main_meter_name ?? 'No Main Meter';
                    $mainMeterStatus = $facility->main_meter_status_label ?? 'No Main Meter';
                    $mainMeterMeta = trim((string) ($facility->main_meter_meta_label ?? ''));
                    $mainMeterCount = collect($facility->main_meters ?? [])->count();
                    $mainMeterTooltip = collect($facility->main_meters ?? [])
                        ->map(function ($meter) {
                            $name = trim((string) ($meter->meter_name ?? 'Main Meter'));
                            $number = trim((string) ($meter->meter_number ?? ''));
                            $status = ucfirst(strtolower(trim((string) ($meter->status ?? 'Unknown'))));
                            $approval = $meter->approved_at ? 'Approved' : 'Pending Approval';
                            $alert = trim((string) ($meter->current_month_alert_level ?? 'No Data'));

                            return trim($name . ($number !== '' ? ' [' . $number . ']' : '') . ' - ' . $status . ' - ' . $approval . ' - Alert: ' . $alert);
                        })
                        ->filter()
                        ->implode(' | ');
                    $mainMeterBreakdown = collect($facility->main_meters ?? [])
                        ->map(function ($meter) {
                            return [
                                'meter_name' => trim((string) ($meter->meter_name ?? 'Main Meter')),
                                'meter_number' => trim((string) ($meter->meter_number ?? '')),
                                'status_label' => ucfirst(strtolower(trim((string) ($meter->status ?? 'Unknown')))),
                                'approval_label' => $meter->approved_at ? 'Approved' : 'Pending Approval',
                                'alert_label' => trim((string) ($meter->current_month_alert_level ?? 'No Data')),
                                'actual_kwh' => is_numeric($meter->current_month_kwh ?? null) ? (float) $meter->current_month_kwh : null,
                                'baseline_kwh' => is_numeric($meter->current_month_baseline_kwh ?? null) ? (float) $meter->current_month_baseline_kwh : null,
                            ];
                        })
                        ->values();
                    $statusSlug = \Illuminate\Support\Str::slug($mainMeterStatus, '-');
                    $facilityStatusLabel = $facility->facility_status_label ?? 'Facility Unknown';
                    $maintenanceStatusLabel = $facility->maintenance_status_label ?? 'No Maintenance Log';
                    $facilityNameRaw = (string) ($facility->name ?? '');
                    $isSeededDualMain = \Illuminate\Support\Str::startsWith($facilityNameRaw, '[Seeder 2M]');
                    $facilityNameDisplay = $isSeededDualMain ? trim((string) preg_replace('/^\[Seeder 2M\]\s*/', '', $facilityNameRaw)) : $facilityNameRaw;
                    $eui = null;
                @endphp
                @php
                    $actualKwh = $record->actual_kwh ?? 0;
                    $floorArea = $facility->floor_area;
                    $eui = ($record && $floorArea > 0) ? number_format($actualKwh / $floorArea, 2) : null;
                    $trendRecommendation = $facility->trend_recommendation ?? 'Not enough data yet to generate a trend recommendation.';
                    $recommendationUrl = route('modules.energy-monitoring.ai-recommendation', ['facility' => $facility->id, 'month' => $selectedMonthInput]);
                    $baselineKwh = $record->baseline_kwh ?? null;
                @endphp
                <tr class="monitor-row {{ $isSeededDualMain ? 'monitor-row-seeded' : '' }}" data-facility-row data-facility-id="{{ (int) $facility->id }}">
                    <td class="cell-facility">
                        <div>{{ $facilityNameDisplay !== '' ? $facilityNameDisplay : $facilityNameRaw }}</div>
                        <div class="cell-meter-meta">{{ $facility->type ?: 'Facility' }}</div>
                        @if($isSeededDualMain)
                            <div class="seeded-facility-badge">Sample: 2 Main Meters</div>
                        @endif
                    </td>
                    <td title="{{ $mainMeterTooltip !== '' ? $mainMeterTooltip : 'No main meter configured' }}">
                        <div class="cell-meter-name">{{ $mainMeterLabel }}</div>
                        @if($mainMeterMeta !== '')
                            <div class="cell-meter-meta">{{ $mainMeterMeta }}</div>
                        @endif
                        <div style="margin-top:5px;"><span class="meter-status-pill status-{{ $statusSlug }}">{{ $mainMeterStatus }}</span></div>
                        @if($mainMeterCount > 1)
                            <button
                                type="button"
                                class="main-meter-trigger"
                                onclick='openMeterBreakdownModal(@json($facilityNameDisplay !== "" ? $facilityNameDisplay : $facilityNameRaw), @json($mainMeterLabel), @json($mainMeterStatus), @json($record && is_numeric($record->actual_kwh ?? null) ? (float) $record->actual_kwh : null), @json($mainMeterBreakdown))'
                            >
                                <span class="cell-meter-hint">View meters</span>
                            </button>
                        @endif
                    </td>
                    <td class="cell-baseline">
                        {{ $record && is_numeric($record->actual_kwh ?? null) ? number_format((float) $record->actual_kwh, 2) : '-' }}
                        @if($mainMeterCount > 1 && $record && is_numeric($record->actual_kwh ?? null))
                            <span class="cell-reading-note">Combined</span>
                        @endif
                    </td>
                    <td class="cell-baseline">
                        {{ $baselineKwh !== null ? number_format($baselineKwh, 2) : '-' }}
                    </td>
                    <td class="trend-value {{ $trendAnalysis === '-' ? '' : (str_contains($trendAnalysis, '+') ? 'trend-positive' : 'trend-normal') }}">
                        {{ $trendAnalysis }}
                        @if($trendSpikeDetected)
                            <div class="trend-spike-badge" style="margin-top:4px;font-size:0.76rem;font-weight:800;color:#b91c1c;">
                                3-Month Spike
                            </div>
                        @endif
                    </td>
                    <td>{{ $eui ?? '-' }}</td>
                    <td>
                        <div class="facility-status-cluster">
                            <span class="monitor-alert-pill alert-pill-level-{{ \Illuminate\Support\Str::slug($alertLevel, '-') }}" data-alert-pill>
                                {{ $alertLevel }}
                            </span>
                            @if(!in_array($maintenanceStatusLabel, ['No Maintenance Log', 'No Maintenance'], true))
                                <span class="facility-status-pill status-{{ \Illuminate\Support\Str::slug($maintenanceStatusLabel, '-') }}">{{ $maintenanceStatusLabel }}</span>
                            @endif
                        </div>
                    </td>
                    <td>
                        @php
                            $iconData = [
                                'Critical' => ['icon' => '!'],
                                'Very High' => ['icon' => '!'],
                                'High' => ['icon' => '!'],
                                'Warning' => ['icon' => 'i'],
                                'Normal' => ['icon' => 'i'],
                                'No Data' => ['icon' => 'i'],
                            ][$alertLevel] ?? ['icon' => 'i'];
                        @endphp
                        <button type="button" title="View AI Recommendation" class="recommendation-btn level-{{ \Illuminate\Support\Str::slug($alertLevel, '-') }}" onclick='openRecommendationModal(@json($facility->id), @json($facility->name), @json($alertLevel), @json($trendRecommendation), @json($recommendationUrl), @json($selectedMonthInput))'>
                            <span class="recommendation-icon">{{ $iconData['icon'] }}</span>
                            <span>View Guidance</span>
                        </button>
                    </td>
                </tr>
            @empty
                <tr><td colspan="8" class="monitor-empty">No facilities found for the selected period.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>

    @if(method_exists($facilities, 'links'))
        <div class="pagination-wrap">
            {{ $facilities->appends(request()->query())->links() }}
        </div>
    @endif
<!-- Recommendation Modal -->
<div id="recommendationModal" class="recommendation-modal">
    <div class="recommendation-modal-inner">
        <div id="recommendationModalBox" class="recommendation-modal-panel">
            <button type="button" onclick="closeRecommendationModal()" class="recommendation-close-icon">&times;</button>
            <div class="recommendation-modal-header">
                <div id="recommendationAlertBadge" class="recommendation-alert-badge">i</div>
                <div class="recommendation-title-wrap">
                    <h2 id="recommendationModalTitle" class="recommendation-title"></h2>
                    <div id="recommendationModalMeta" class="recommendation-meta"></div>
                </div>
            </div>
            <div id="recommendationText" class="recommendation-message-card"></div>
            <div class="recommendation-footer">
                <button type="button" onclick="closeRecommendationModal()" class="recommendation-close-btn">Close</button>
            </div>
        </div>
    </div>
</div>

<div id="meterBreakdownModal" class="recommendation-modal">
    <div class="recommendation-modal-inner">
        <div class="recommendation-modal-panel">
            <button type="button" onclick="closeMeterBreakdownModal()" class="recommendation-close-icon">&times;</button>
            <div class="recommendation-modal-header">
                <div class="recommendation-alert-badge">M</div>
                <div class="recommendation-title-wrap">
                    <h2 id="meterBreakdownModalTitle" class="recommendation-title"></h2>
                    <div id="meterBreakdownModalMeta" class="recommendation-meta" style="display: block;"></div>
                </div>
            </div>
            <div class="meter-breakdown-total">
                <div class="meter-breakdown-total-label">Combined Main Meter kWh</div>
                <div id="meterBreakdownTotalKwh" class="meter-breakdown-total-value">-</div>
            </div>
            <div id="meterBreakdownList" class="meter-breakdown-list"></div>
            <div class="recommendation-footer">
                <button type="button" onclick="closeMeterBreakdownModal()" class="recommendation-close-btn">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
const recommendationCache = {};
const metricNumberFormatter = new Intl.NumberFormat('en-PH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
});

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function formatMetricValue(value, suffix = '') {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) {
        return 'No reading';
    }

    return `${metricNumberFormatter.format(numeric)}${suffix}`;
}

function normalizeAlertLevel(level) {
    const raw = String(level || '').trim().toLowerCase();
    if (raw === 'critical') return 'Critical';
    if (raw === 'very high' || raw === 'very_high') return 'Very High';
    if (raw === 'high') return 'High';
    if (raw === 'warning' || raw === 'moderate') return 'Warning';
    if (raw === 'normal' || raw === 'low') return 'Normal';
    return 'No Data';
}

function alertSlug(alertLevel) {
    return normalizeAlertLevel(alertLevel).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

function alertPillClass(alertLevel) {
    return `alert-pill-level-${alertSlug(alertLevel)}`;
}

function updateRecommendationSource(meta, source) {
    if (!meta) return;

    const normalized = String(source || 'rules').toLowerCase();
    meta.style.display = 'inline-flex';
    meta.classList.remove('source-ai', 'source-system');
    meta.classList.add(normalized === 'ai' ? 'source-ai' : 'source-system');
    meta.textContent = normalized === 'ai' ? 'AI Generated' : 'System Generated';
}

function updateTableAlertPill(facilityId, alertLevel) {
    const row = document.querySelector(`[data-facility-row][data-facility-id="${facilityId}"]`);
    if (!row) return;
    const pill = row.querySelector('[data-alert-pill]');
    if (!pill) return;

    const normalized = normalizeAlertLevel(alertLevel);
    Array.from(pill.classList)
        .filter((name) => name.startsWith('alert-pill-level-'))
        .forEach((name) => pill.classList.remove(name));
    pill.classList.add(`alert-pill-level-${alertSlug(normalized)}`);
    pill.textContent = normalized;
}

async function openRecommendationModal(facilityId, facilityName, alertLevel, fallbackRecommendation, recommendationUrl, selectedMonth) {
    const modal = document.getElementById('recommendationModal');
    const title = document.getElementById('recommendationModalTitle');
    const meta  = document.getElementById('recommendationModalMeta');
    const text  = document.getElementById('recommendationText');
    const box   = document.getElementById('recommendationModalBox');
    const badge = document.getElementById('recommendationAlertBadge');
    const isDark = document.body.classList.contains('dark-mode');
    const alertStyles = {
        'Critical': { color: '#991b1b', bg: '#fef2f2', border: '#fca5a5', badgeBg: '#ffffff', badgeColor: '#991b1b', darkBg: 'rgba(127,29,29,0.22)', darkBorder: 'rgba(248,113,113,0.35)', darkBadgeBg: '#0f172a', darkBadgeColor: '#fecaca', icon: '!' },
        'Very High': { color: '#be123c', bg: '#fff1f2', border: '#fda4af', badgeBg: '#ffffff', badgeColor: '#be123c', darkBg: 'rgba(190,18,60,0.18)', darkBorder: 'rgba(244,114,182,0.30)', darkBadgeBg: '#0f172a', darkBadgeColor: '#fda4af', icon: '!' },
        'High': { color: '#c2410c', bg: '#fff7ed', border: '#fdba74', badgeBg: '#ffffff', badgeColor: '#c2410c', darkBg: 'rgba(194,65,12,0.18)', darkBorder: 'rgba(251,146,60,0.30)', darkBadgeBg: '#0f172a', darkBadgeColor: '#fdba74', icon: '!' },
        'Moderate': { color: '#92400e', bg: '#fef3c7', border: '#fcd34d', badgeBg: '#ffffff', badgeColor: '#92400e', darkBg: 'rgba(146,64,14,0.18)', darkBorder: 'rgba(251,191,36,0.28)', darkBadgeBg: '#0f172a', darkBadgeColor: '#fde68a', icon: 'i' },
        'Warning': { color: '#9a4a12', bg: '#f7edc0', border: '#f3c23c', badgeBg: '#ffffff', badgeColor: '#b45309', darkBg: 'rgba(180,83,9,0.16)', darkBorder: 'rgba(251,191,36,0.24)', darkBadgeBg: '#0f172a', darkBadgeColor: '#fde68a', icon: 'i' },
        'Low': { color: '#166534', bg: '#f0fdf4', border: '#86efac', badgeBg: '#ffffff', badgeColor: '#166534', darkBg: 'rgba(22,101,52,0.16)', darkBorder: 'rgba(74,222,128,0.24)', darkBadgeBg: '#0f172a', darkBadgeColor: '#86efac', icon: 'i' },
        'Normal': { color: '#1d4ed8', bg: '#eff6ff', border: '#93c5fd', badgeBg: '#ffffff', badgeColor: '#1d4ed8', darkBg: 'rgba(37,99,235,0.14)', darkBorder: 'rgba(147,197,253,0.22)', darkBadgeBg: '#0f172a', darkBadgeColor: '#93c5fd', icon: 'i' },
        'No Data': { color: '#475569', bg: '#f1f5f9', border: '#cbd5e1', badgeBg: '#ffffff', badgeColor: '#475569', darkBg: 'rgba(51,65,85,0.22)', darkBorder: 'rgba(148,163,184,0.20)', darkBadgeBg: '#0f172a', darkBadgeColor: '#cbd5e1', icon: 'i' },
    };
    const applyAlertStyle = (level) => {
        const normalized = normalizeAlertLevel(level);
        const style = alertStyles[normalized] || alertStyles['No Data'];
        text.style.color = isDark ? '#e2e8f0' : style.color;
        text.style.background = isDark ? style.darkBg : style.bg;
        text.style.borderColor = isDark ? style.darkBorder : style.border;
        if (badge) {
            badge.textContent = style.icon;
            badge.style.background = isDark ? style.darkBadgeBg : style.badgeBg;
            badge.style.color = isDark ? style.darkBadgeColor : style.badgeColor;
            badge.style.border = isDark ? `1.5px solid ${style.darkBorder}` : `1.5px solid ${style.border}`;
        }
    };

    const initialAlert = normalizeAlertLevel(alertLevel);
    const cacheKey = `${facilityId}:${String(selectedMonth || '')}`;
    title.textContent = `Recommendation for ${facilityName}`;
    modal.dataset.facilityId = String(facilityId);
    if (meta) {
        updateRecommendationSource(meta, 'rules');
    }
    text.textContent = fallbackRecommendation || 'No recommendation';
    applyAlertStyle(initialAlert);
    box.style.background = isDark ? '#111827' : '#fff';
    modal.style.display = 'flex';

    if (recommendationCache[cacheKey]) {
        const cached = recommendationCache[cacheKey];
        text.textContent = cached.recommendation;
        applyAlertStyle(cached.alertLevel);
        updateTableAlertPill(facilityId, cached.alertLevel);
        if (meta) {
            updateRecommendationSource(meta, cached.source);
        }
        return;
    }

    if (!recommendationUrl) {
        return;
    }

    if (meta) {
        meta.classList.remove('source-ai', 'source-system');
        meta.textContent = 'Loading AI recommendation...';
    }

    try {
        const response = await fetch(recommendationUrl, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
            },
        });

        if (!response.ok) {
            throw new Error('Request failed');
        }

        const data = await response.json();
        const recommendation = (data && data.recommendation) ? String(data.recommendation).trim() : '';
        if (recommendation === '') {
            throw new Error('Empty recommendation');
        }
        const resolvedAlertLevel = normalizeAlertLevel(data && data.alert_level ? data.alert_level : initialAlert);
        const resolvedSource = String(data && data.recommendation_source ? data.recommendation_source : 'rules').toLowerCase();

        recommendationCache[cacheKey] = {
            recommendation,
            alertLevel: resolvedAlertLevel,
            source: resolvedSource,
        };
        updateTableAlertPill(facilityId, resolvedAlertLevel);
        if (modal.dataset.facilityId === String(facilityId)) {
            text.textContent = recommendation;
            applyAlertStyle(resolvedAlertLevel);
            if (meta) {
                updateRecommendationSource(meta, resolvedSource);
            }
        }
    } catch (error) {
        if (meta) {
            updateRecommendationSource(meta, 'rules');
        }
    }
}
function closeRecommendationModal() {
    document.getElementById('recommendationModal').style.display = 'none';
}

function openMeterBreakdownModal(facilityName, meterLabel, meterStatus, totalKwh, meters) {
    const modal = document.getElementById('meterBreakdownModal');
    const title = document.getElementById('meterBreakdownModalTitle');
    const meta = document.getElementById('meterBreakdownModalMeta');
    const total = document.getElementById('meterBreakdownTotalKwh');
    const list = document.getElementById('meterBreakdownList');
    const rows = Array.isArray(meters) ? meters : [];

    title.textContent = `${facilityName} Main Meter Breakdown`;
    meta.textContent = rows.length > 1 ? `${rows.length} main meters - ${meterStatus}` : `${meterLabel} - ${meterStatus}`;
    total.textContent = formatMetricValue(totalKwh, ' kWh');

    if (rows.length === 0) {
        list.innerHTML = '<div class="meter-breakdown-card"><div class="meter-breakdown-card-title">No main meter data available.</div></div>';
        modal.style.display = 'flex';
        return;
    }

    list.innerHTML = rows.map((meter, index) => {
        const number = String(meter && meter.meter_number ? meter.meter_number : '').trim();
        const subtitle = number !== '' ? `Meter No. ${escapeHtml(number)}` : 'Meter number not set';
        const status = escapeHtml(meter && meter.status_label ? meter.status_label : 'Unknown');
        const approval = escapeHtml(meter && meter.approval_label ? meter.approval_label : 'Pending Approval');
        const alertLabelRaw = meter && meter.alert_label ? meter.alert_label : 'No Data';
        const alertLabel = escapeHtml(alertLabelRaw);
        const baseline = Number.isFinite(Number(meter && meter.baseline_kwh))
            ? `Baseline ${formatMetricValue(meter.baseline_kwh, ' kWh')}`
            : 'No baseline';

        return `
            <div class="meter-breakdown-card">
                <div class="meter-breakdown-card-head">
                    <div>
                        <div class="meter-breakdown-card-title">${escapeHtml(meter && meter.meter_name ? meter.meter_name : `Main Meter ${index + 1}`)}</div>
                        <div class="meter-breakdown-card-subtitle">${subtitle}</div>
                    </div>
                    <div class="meter-breakdown-card-kwh">
                        ${formatMetricValue(meter && meter.actual_kwh, ' kWh')}
                        <small>Selected period</small>
                    </div>
                </div>
                <div class="meter-breakdown-meta">
                    <span class="meter-breakdown-pill">${status}</span>
                    <span class="meter-breakdown-pill">${approval}</span>
                    <span class="meter-breakdown-pill ${alertPillClass(alertLabelRaw)}">Alert: ${alertLabel}</span>
                    <span class="meter-breakdown-pill">${escapeHtml(baseline)}</span>
                </div>
            </div>
        `;
    }).join('');

    modal.style.display = 'flex';
}

function closeMeterBreakdownModal() {
    document.getElementById('meterBreakdownModal').style.display = 'none';
}

// Auto-hide alert
window.addEventListener('DOMContentLoaded', () => {
    const success = document.getElementById('successAlert');
    if(success) setTimeout(() => success.style.opacity = '0', 3000);

    const recommendationModal = document.getElementById('recommendationModal');
    const meterBreakdownModal = document.getElementById('meterBreakdownModal');

    if (recommendationModal) {
        recommendationModal.addEventListener('click', (event) => {
            if (event.target === recommendationModal) {
                closeRecommendationModal();
            }
        });
    }

    if (meterBreakdownModal) {
        meterBreakdownModal.addEventListener('click', (event) => {
            if (event.target === meterBreakdownModal) {
                closeMeterBreakdownModal();
            }
        });
    }
});
</script>

@endsection
