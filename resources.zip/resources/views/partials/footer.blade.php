<footer class="footer" style="background:#22223b; color:#e0e7ef; padding:32px 0 18px 0; text-align:center; font-size:1rem; margin-top:48px;">
    <div class="container">
        <div class="mb-2">© {{ date('Y') }} Energy System Portal · All Rights Reserved</div>
        <div>For support, email <a href="mailto:support@energysystem.com" style="color:#a5b4fc; text-decoration:underline;">support@energysystem.com</a> or call <a href="tel:+15551234567" style="color:#a5b4fc; text-decoration:underline;">+1 (555) 123-4567</a></div>
        <div class="mt-2">
            <a href="#" class="me-3" style="color:#3b82f6;"><i class="fab fa-facebook fa-lg"></i></a>
            <a href="#" class="me-3" style="color:#38bdf8;"><i class="fab fa-twitter fa-lg"></i></a>
            <a href="#" style="color:#6366f1;"><i class="fab fa-linkedin fa-lg"></i></a>
        </div>
    </div>
</footer>
