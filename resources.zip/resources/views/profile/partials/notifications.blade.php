<div style="padding:18px 0;">
    <h4 style="font-size:1.15rem;font-weight:700;margin-bottom:18px;">Notification Preferences</h4>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:18px 14px;align-items:center;">
        <label style="font-size:1.05rem;"><input type="checkbox" checked disabled style="margin-right:7px;"> Energy Alerts</label>
        <label style="font-size:1.05rem;"><input type="checkbox" checked disabled style="margin-right:7px;"> Incident Updates</label>
        <!-- Billing Notifications removed -->
        <label style="font-size:1.05rem;"><input type="checkbox" checked disabled style="margin-right:7px;"> Due Date Reminders</label>
        <label style="font-size:1.05rem;"><input type="checkbox" checked disabled style="margin-right:7px;"> Email</label>
        <label style="font-size:1.05rem;"><input type="checkbox" disabled style="margin-right:7px;"> SMS</label>
    </div>
</div>